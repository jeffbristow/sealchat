/* =====================================================================
 * Seal Chat — webaccess.js   (use Seal Chat from a phone browser, 1.4.0)
 * ---------------------------------------------------------------------
 * The web interface (Seal Chat Web, on YOUR website, e.g. https://example.com/chat/)
 * is a remote screen for this app. Your PGP key never leaves this
 * computer: Seal Chat reads/sends your messages as usual and passes
 * them to the paired browser, sealed with a key only the two share.
 * The website's relay.php only carries sealed blobs.
 *
 * OFF BY DEFAULT. When on, it works in two speeds:
 *   IDLE    every N seconds (Settings, default 30) one tiny request for
 *           the website's static "wake" file, asking "changed since…?".
 *           The web server answers "304 Not Modified" without running
 *           PHP. Nothing else is sent.
 *   ACTIVE  when the wake file HAS changed (someone opened the web
 *           interface) or while pairing: Seal Chat calls relay.php and
 *           waits there for messages (~1-2 s delivery), until the web
 *           interface has been quiet for 5 minutes.
 * It can also switch itself off after a set time (1 h / 8 h / 24 h).
 *
 * Saved (encrypted, in vault.dat → vault.web): the website address, the
 * relay code + mailbox token, and each paired device: its name, its key,
 * a hash of its PIN. Settings (plain): webEnabled, webUntil, webIdleSec,
 * webViaTor.
 *
 * Sections:
 *   1. Crypto (must match crypto.js in Seal Chat Web)
 *   2. WebAccess: state, status, on/off
 *   3. Connecting to the website (connection link → mailbox)
 *   4. The loop: idle wake-file checks ↔ active listening
 *   5. Pairing a device (QR code, approve / decline)
 *   6. Requests from a paired device (PIN, contacts, chats, sending)
 *   7. Sending to devices + live updates
 * ===================================================================== */

const crypto = require('crypto');
const { EventEmitter } = require('events');
const { request } = require('./webhttp');

const ACTIVE_MS = 5 * 60e3;        // stay listening this long after the last device message
const PAIR_MS = 10 * 60e3;         // a pairing QR code works this long
const SESSION_MS = 12 * 3600e3;    // a PIN unlock lasts this long (while the page is open)
const PIN_TRIES = 10;              // wrong PINs before the device is removed
const PIN_ITER = 150000;
const WAIT_S = 20;                 // how long relay.php holds a "recv" open

/* =================================================================
 * 1. CRYPTO  (same as Seal Chat Web's crypto.js)
 * ================================================================= */
const b64u = b => Buffer.from(b).toString('base64url');
const unb64u = s => Buffer.from(String(s || ''), 'base64url');
const sha256hex = s => crypto.createHash('sha256').update(s).digest('hex');
const hkdf = (ikm, salt, info, len) => Buffer.from(crypto.hkdfSync('sha256', ikm, salt || Buffer.alloc(0), Buffer.from(info), len));
const AAD = {
  pair: (dir, tid) => `sealchat-web-pair-v1|${dir}|${tid}`,
  msg: (dir, devId) => `sealchat-web-v1|${dir}|${devId}`
};
function pairSecrets(P) {
  return { pairKey: hkdf(P, null, 'sealchat-web-pair-v1', 32), ticket: b64u(hkdf(P, null, 'sealchat-web-ticket-v1', 24)) };
}
function deviceSecrets(shared, P, devId) {
  const c = hkdf(shared, P, 'sealchat-web-code-v1', 4);
  const six = String(c.readUInt32BE(0) % 1000000).padStart(6, '0');
  return { key: hkdf(shared, P, 'sealchat-web-key-v1|' + devId, 32), code: six.slice(0, 3) + ' ' + six.slice(3) };
}
function seal(key, aad, obj) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  c.setAAD(Buffer.from(aad));
  const ct = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final(), c.getAuthTag()]);
  return JSON.stringify({ n: b64u(iv), c: b64u(ct) });
}
function open(key, aad, text) {
  const o = JSON.parse(text);
  const all = unb64u(o.c);
  if (all.length < 16) throw new Error('short');
  const d = crypto.createDecipheriv('aes-256-gcm', key, unb64u(o.n));
  d.setAAD(Buffer.from(aad));
  d.setAuthTag(all.subarray(all.length - 16));
  return JSON.parse(Buffer.concat([d.update(all.subarray(0, all.length - 16)), d.final()]).toString('utf8'));
}
const pbkdf2 = (pin, salt) => new Promise((res, rej) => crypto.pbkdf2(String(pin), salt, PIN_ITER, 32, 'sha256', (e, k) => e ? rej(e) : res(k)));

/** "https://site/sealchat/web/#relay=CODE" → { base, code } */
function parseLink(text, allowHttp) {
  const s = String(text || '').trim();
  let u;
  try { u = new URL(s); } catch { throw new Error('Paste the connection link from your Seal Chat Web setup page (admin.php)'); }
  if (u.protocol !== 'https:' && !(allowHttp && u.protocol === 'http:')) throw new Error('The link must start with https://');
  const m = /(?:^|[#&?])relay=([A-Za-z0-9-]{8,40})/.exec(u.hash + '&' + u.search);
  if (!m) throw new Error('That link has no relay code in it. Copy the whole "connection link" from your Seal Chat Web setup page (admin.php).');
  let p = u.pathname.replace(/index\.(php|html)$/i, '');
  if (!p.endsWith('/')) p += '/';
  return { base: `${u.protocol}//${u.host}${p}`, code: m[1].toUpperCase() };
}

/* =================================================================
 * 2. WEBACCESS
 * ================================================================= */
class WebAccess extends EventEmitter {
  /**
   * @param {object} o
   *   state()        → the saved object (vault.web), changed in place
   *   save()         → saves it (encrypted)
   *   settings()     → plain settings; setSettings(patch)
   *   socksPort()    → Tor's SOCKS port or null
   *   handler        { me(), contacts(), history(cid, before), send(cid, text), read(cid) }
   *   ca, allowHttp  (tests only)
   */
  constructor(o) {
    super();
    this.o = o;
    this.mode = 'off';           // off | idle | active | waiting-tor | error
    this.error = null;
    this.lastCheck = 0;
    this.activeUntil = 0;
    this.ack = 0;
    this.pairing = null;
    this.sessions = new Map();   // devId -> { sid, at }
    this.sendChains = new Map(); // devId/tid -> Promise (keeps messages in order)
    this.outSeq = 0;
    this.running = false;
    this._kick = null;
    this.stats = { checks: 0, polls: 0 };
  }

  st() { const s = this.o.state(); if (!s.devices) s.devices = {}; return s; }
  S() { return this.o.settings(); }
  enabled() {
    const s = this.S();
    if (!s.webEnabled) return false;
    if (s.webUntil && Date.now() > s.webUntil) { this.o.setSettings({ webEnabled: false, webUntil: undefined }); this._changed(); return false; }
    return true;
  }
  idleMs() { return this.o.idleMs || Math.max(10, Math.min(900, Number(this.S().webIdleSec) || 30)) * 1000; }
  activeMs() { return this.o.activeMs || ACTIVE_MS; }
  viaTor() { return this.S().webViaTor !== false; }
  _net() {
    const socksPort = this.viaTor() ? this.o.socksPort() : null;
    return { socksPort, ca: this.o.ca, allowHttp: !!this.o.allowHttp };
  }

  /** Everything the Settings screen shows. */
  status() {
    const s = this.st(), S = this.S();
    return {
      enabled: !!S.webEnabled, until: S.webUntil || null, idleSec: this.idleMs() / 1000, viaTor: this.viaTor(),
      linked: !!s.box, base: s.base || '', mode: this.mode, error: this.error, errorCode: this.mode === 'error' ? this.errorCode || null : null, lastCheck: this.lastCheck,
      devices: Object.entries(s.devices).map(([id, d]) => ({ id, name: d.name, added: d.added, lastUsed: d.lastUsed || 0, connected: this._sessionAlive(id) && this.mode === 'active' })),
      pairing: this.pairing ? { tid: this.pairing.tid, stage: this.pairing.stage, name: this.pairing.cand && this.pairing.cand.name, code: this.pairing.cand && this.pairing.cand.code, exp: this.pairing.exp } : null,
      stats: this.stats
    };
  }
  _changed() { this.emit('status', this.status()); }

  /** Turns web access on (optionally for some hours) or off. */
  setEnabled(on, hours) {
    if (on && !this.st().box) throw new Error('First paste the connection link from your website');
    this.o.setSettings({ webEnabled: !!on, webUntil: on && Number(hours) > 0 ? Date.now() + Number(hours) * 3600e3 : undefined });
    if (!on) { this.sessions.clear(); this.pairing = null; this.activeUntil = 0; }
    this.kick();
    this._changed();
    return this.status();
  }

  start() { if (this.running) return; this.running = true; this._loop(); }
  stop() { this.running = false; this.kick(); }
  /** Wakes the loop now (settings changed, pairing started, Tor ready …). */
  kick() { if (this._kick) { const k = this._kick; this._kick = null; k(); } }
  _sleep(ms) { return new Promise(r => { const t = setTimeout(() => { this._kick = null; r(); }, ms); this._kick = () => { clearTimeout(t); r(); }; }); }

  /* =================================================================
   * 3. CONNECTING TO THE WEBSITE
   * ================================================================= */
  async _call(action, body, timeoutMs) {
    const s = this.st();
    const r = await request(s.base + 'relay.php?a=' + action, {
      ...this._net(), method: 'POST', body: JSON.stringify(body || {}), timeoutMs: timeoutMs || 60000,
      headers: { 'X-SC-Box': s.box, 'Authorization': 'Bearer ' + s.token, 'X-SC-Auth': s.token }
    });
    let j = null;
    try { j = JSON.parse(r.body.toString('utf8')); } catch { /* not JSON */ }
    if (!j) {
      // a page instead of the relay's answer: through Tor, usually the host's "blocked visitor" page
      if (this.viaTor() && [403, 429, 503].includes(r.status)) {
        const e = new Error(`The website answered ${r.status} (blocked) to a visit through Tor. Your website doesn't need to be on Tor — but its host seems to block visitors that arrive through Tor.`);
        e.code = 'TOR_BLOCKED'; throw e;
      }
      const e = new Error(r.status === 404 ? 'relay.php was not found at ' + s.base + ' — is the web interface uploaded there?' : `The website answered ${r.status} instead of the relay's reply`);
      e.code = 'HTTP' + r.status; throw e;
    }
    if (!j.ok) { const e = new Error(j.error || 'The relay refused'); e.code = j.code; e.status = r.status; throw e; }
    return j;
  }

  /** Paste of the connection link from admin.php → sets up this computer's mailbox. */
  async connect(linkText) {
    const { base, code } = parseLink(linkText, this.o.allowHttp);
    const s = this.st();
    if (s.box && s.base === base) {           // same site: keep the mailbox + paired devices
      s.code = code; this.o.save();
      await this._register();
      return this.status();
    }
    if (s.box) await this.disconnect().catch(() => {});
    Object.assign(s, { base, code, box: crypto.randomBytes(16).toString('hex'), token: b64u(crypto.randomBytes(32)), wake: null, devices: {}, lastWakeTag: null });
    try { await this._register(); }
    catch (e) { for (const k of ['base', 'code', 'box', 'token', 'wake']) delete s[k]; this.o.save(); throw e; }
    this.o.save();
    this.kick(); this._changed();
    return this.status();
  }

  async _register() {
    const s = this.st();
    const j = await this._call('register', { code: s.code, token: s.token });
    s.wake = String(j.wake || '');
    this.o.save();
    await this._syncAllow();
  }

  /** Removes this computer's mailbox from the website and forgets the paired devices. */
  async disconnect() {
    const s = this.st();
    if (s.box) { try { await this._call('unregister', {}); } catch { /* website gone: forget anyway */ } }
    for (const k of Object.keys(s)) delete s[k];
    s.devices = {};
    this.sessions.clear(); this.pairing = null;
    this.o.setSettings({ webEnabled: false, webUntil: undefined });
    this.o.save();
    this.kick(); this._changed();
    return this.status();
  }

  /** Tells the relay which devices (and which pairing ticket) may use the mailbox. */
  async _syncAllow() {
    const s = this.st();
    const devices = {};
    for (const [id, d] of Object.entries(s.devices)) devices[id] = d.th;
    const tickets = {};
    if (this.pairing && Date.now() < this.pairing.exp) tickets[this.pairing.tid] = { h: sha256hex(this.pairing.ticket), exp: Math.floor(this.pairing.exp / 1000) };
    await this._call('allow', { devices, tickets });
  }

  /** The mailbox was removed on the website (or the code changed): connect again. */
  async _recover(e) {
    if (!['nobox', 'auth'].includes(e.code)) return false;
    const s = this.st();
    if (e.code === 'auth') s.box = crypto.randomBytes(16).toString('hex');   // someone else's now
    try { await this._register(); this.error = null; return true; } catch (e2) { this.error = e2.message; return false; }
  }

  /* =================================================================
   * 4. THE LOOP
   * ================================================================= */
  async _loop() {
    let backoff = 0;
    while (this.running) {
      const s = this.st();
      if (!this.enabled() || !s.box) {
        if (this.mode !== 'off') { this.mode = 'off'; this._changed(); }
        await this._sleep(60e3); continue;
      }
      if (this.viaTor() && !this.o.socksPort()) {
        if (this.mode !== 'waiting-tor') { this.mode = 'waiting-tor'; this._changed(); }
        await this._sleep(5000); continue;
      }
      try {
        if (Date.now() < this.activeUntil || (this.pairing && Date.now() < this.pairing.exp)) {
          if (this.mode !== 'active') { this.mode = 'active'; this.error = null; this._changed(); }
          await this._poll();
        } else {
          if (this.mode !== 'idle') { this.mode = 'idle'; this.sessions.clear(); this._changed(); }
          if (this.pairing && Date.now() >= this.pairing.exp) { this.pairing = null; this._changed(); }
          const woke = await this._checkWake();
          if (this.error) { this.error = null; this._changed(); }
          if (!woke) await this._sleep(this.idleMs());
        }
        backoff = 0;
      } catch (e) {
        if (await this._recover(e)) continue;
        this.error = e.message; this.errorCode = e.code || null;
        this.mode = 'error';
        this._changed();
        backoff = Math.min(backoff ? backoff * 2 : 15000, 300000);
        await this._sleep(backoff);
      }
    }
    this.mode = 'off';
  }

  /** IDLE: has the wake file changed? (304 = no; costs no PHP on the website). */
  async _checkWake() {
    const s = this.st();
    if (!s.wake) { await this._register(); }
    const tag = s.lastWakeTag || {};
    const headers = {};
    if (tag.etag) headers['If-None-Match'] = tag.etag;
    if (tag.lm) headers['If-Modified-Since'] = tag.lm;
    const r = await request(s.base + s.wake, { ...this._net(), headers, timeoutMs: 60000, maxBytes: 4096 });
    this.lastCheck = Date.now(); this.stats.checks++;
    if (r.status === 304) return false;
    if (r.status === 404) { const e = new Error('nobox'); e.code = 'nobox'; throw e; }
    if (r.status !== 200) {
      const e = new Error(`The website answered ${r.status} for the wake file`);
      if (this.viaTor() && [403, 429, 503].includes(r.status)) { e.message = `The website answered ${r.status} (blocked) to a visit through Tor — its host seems to block visitors that arrive through Tor.`; e.code = 'TOR_BLOCKED'; }
      throw e;
    }
    const body = sha256hex(r.body);
    const changed = tag.body !== body;
    s.lastWakeTag = { etag: r.headers.etag || null, lm: r.headers['last-modified'] || null, body };
    this.o.save();
    if (changed) { this.activeUntil = Date.now() + Math.min(2 * 60e3, this.activeMs()); this.emit('log', 'web access: woken'); return true; }
    return false;
  }

  /** ACTIVE: wait at relay.php for messages from devices. */
  async _poll() {
    const wait = this.o.waitS || WAIT_S;
    const j = await this._call('recv', { ack: this.ack, wait, until: Math.floor(this.activeUntil / 1000) }, (wait + 40) * 1000);
    this.stats.polls++;
    this.lastCheck = Date.now();
    for (const it of j.items || []) {
      this.ack = Math.max(this.ack, Number(it.id) || 0);
      try {
        if (/^d:/.test(it.f)) await this._fromDevice(it.f.slice(2), it.d);
        else if (/^t:/.test(it.f)) await this._fromPairing(it.f.slice(2), it.d);
      } catch (e) { this.emit('log', 'web access: ' + e.message); }
    }
  }

  /* =================================================================
   * 5. PAIRING
   * ================================================================= */
  /** Starts pairing: returns the link to show as a QR code (valid 10 minutes). */
  async startPairing() {
    const s = this.st();
    if (!s.box) throw new Error('First paste the connection link from your website');
    if (!this.enabled()) throw new Error('Turn web access on first');
    if (Object.keys(s.devices).length >= 10) throw new Error('You can pair up to 10 devices — remove one first');
    const P = crypto.randomBytes(32);
    const tid = crypto.randomBytes(8).toString('hex');
    const { pairKey, ticket } = pairSecrets(P);
    this.pairing = { tid, P, pairKey, ticket, exp: Date.now() + PAIR_MS, stage: 'waiting', cand: null };
    await this._syncAllow();
    this.kick(); this._changed();
    return { link: `${s.base}#pair=${s.box}.${tid}.${b64u(P)}`, exp: this.pairing.exp, tid };
  }

  cancelPairing() { this.pairing = null; this._syncAllow().catch(() => {}); this._changed(); }

  async _fromPairing(tid, data) {
    const p = this.pairing;
    if (!p || p.tid !== tid || Date.now() > p.exp) return;
    const m = open(p.pairKey, AAD.pair('d2c', tid), data);
    if (m.t !== 'pair' || p.stage !== 'waiting') return;
    const dev = String(m.dev || ''), pub = unb64u(m.pub), th = String(m.th || '');
    if (!/^[a-f0-9]{16}$/.test(dev) || pub.length !== 65 || !/^[a-f0-9]{64}$/.test(th)) throw new Error('bad pairing request');
    if (!/^\d{4,12}$/.test(String(m.pin || ''))) throw new Error('bad PIN');
    const ec = crypto.createECDH('prime256v1');
    ec.generateKeys();
    const shared = ec.computeSecret(pub);
    const { key, code } = deviceSecrets(shared, p.P, dev);
    const salt = crypto.randomBytes(16);
    p.cand = { dev, th, key, code, name: String(m.name || 'Browser').replace(/[\x00-\x1f]/g, '').slice(0, 40) || 'Browser', pin: { salt: b64u(salt), hash: b64u(await pbkdf2(m.pin, salt)), iter: PIN_ITER } };
    p.stage = 'confirm';
    await this._sendRaw('t:' + tid, [seal(p.pairKey, AAD.pair('c2d', tid), { t: 'pairKey', pub: b64u(ec.getPublicKey()) })]);
    this._changed();
    this.emit('pairRequest', { tid, name: p.cand.name, code });
  }

  /** You clicked Approve (after checking the code matches the one on the device). */
  async approvePairing(tid) {
    const p = this.pairing;
    if (!p || p.tid !== tid || p.stage !== 'confirm') throw new Error('That pairing request has expired');
    const c = p.cand, s = this.st();
    s.devices[c.dev] = { name: c.name, k: b64u(c.key), th: c.th, pin: c.pin, fails: 0, inSeq: 0, added: Date.now(), lastUsed: 0 };
    this.o.save();
    p.stage = 'approved';
    await this._syncAllow();                  // the device's own token works from now on
    await this._sendRaw('t:' + tid, [seal(p.pairKey, AAD.pair('c2d', tid), { t: 'pairOk', name: c.name })]);
    this.activeUntil = Date.now() + this.activeMs();
    this._changed();
    return this.status();
  }

  async declinePairing(tid) {
    const p = this.pairing;
    if (!p || p.tid !== tid) return this.status();
    await this._sendRaw('t:' + tid, [seal(p.pairKey, AAD.pair('c2d', tid), { t: 'pairNo' })]).catch(() => {});
    p.stage = 'declined'; p.exp = Math.min(p.exp, Date.now() + 60e3);
    this._changed();
    return this.status();
  }

  async removeDevice(id) {
    const s = this.st();
    const d = s.devices[id];
    if (!d) return this.status();
    try { await this._send(id, { t: 'revoked', why: 'removed' }); } catch { /* offline */ }
    delete s.devices[id]; this.sessions.delete(id);
    this.o.save();
    await this._syncAllow().catch(() => {});
    this._changed();
    return this.status();
  }

  /* =================================================================
   * 6. REQUESTS FROM A PAIRED DEVICE
   * ================================================================= */
  _sessionAlive(id) { const x = this.sessions.get(id); return !!x && Date.now() - x.at < SESSION_MS; }

  async _fromDevice(devId, data) {
    const s = this.st();
    const d = s.devices[devId];
    if (!d) return;
    const key = unb64u(d.k);
    let m;
    try { m = open(key, AAD.msg('d2c', devId), data); } catch { return; }   // not sealed with this device's key: ignore
    if (!(Number(m.s) > (d.inSeq || 0))) return;                            // old or repeated
    d.inSeq = Number(m.s); d.lastUsed = Date.now();
    this.o.save();
    this.activeUntil = Date.now() + this.activeMs();
    if (this.pairing && this.pairing.cand && this.pairing.cand.dev === devId) { this.pairing = null; this._syncAllow().catch(() => {}); }   // pairing finished
    const reply = o => this._send(devId, { ...o, re: m.q });

    if (m.t === 'hello') {
      if (d.fails >= 3) await new Promise(r => setTimeout(r, Math.min(10, d.fails) * 400));
      const ok = crypto.timingSafeEqual(await pbkdf2(String(m.pin || ''), unb64u(d.pin.salt)), unb64u(d.pin.hash));
      if (!ok) {
        d.fails = (d.fails || 0) + 1; this.o.save();
        if (d.fails >= PIN_TRIES) {
          await reply({ t: 'revoked', why: 'pin' });
          delete s.devices[devId]; this.o.save(); await this._syncAllow().catch(() => {});
          this.emit('log', 'web access: device removed after too many wrong PINs');
        } else await reply({ t: 'badpin', left: PIN_TRIES - d.fails });
        this._changed();
        return;
      }
      d.fails = 0; this.o.save();
      const sid = b64u(crypto.randomBytes(18));
      this.sessions.set(devId, { sid, at: Date.now() });
      await reply({ t: 'welcome', sid, me: this.o.handler.me(), contacts: this.o.handler.contacts(), name: d.name });
      this._changed();
      return;
    }
    const sess = this.sessions.get(devId);
    if (m.t === 'bye') { if (sess && sess.sid === m.sid) this.sessions.delete(devId); this._quietCheck(); this._changed(); return; }
    if (!sess || sess.sid !== m.sid || !this._sessionAlive(devId)) { await reply({ t: 'relogin' }); return; }
    sess.at = Date.now();
    const h = this.o.handler;
    try {
      switch (m.t) {
        case 'ping': await reply({ t: 'pong' }); break;
        case 'contacts': await reply({ t: 'contacts', list: h.contacts() }); break;
        case 'history': await reply({ t: 'history', cid: m.cid, ...h.history(String(m.cid || ''), m.before || null) }); break;
        case 'send': await reply({ t: 'sent', cid: m.cid, tmp: m.tmp, msg: h.send(String(m.cid || ''), String(m.text || '')) }); break;
        case 'read': h.read(String(m.cid || '')); await reply({ t: 'ok' }); break;
        case 'unpair':                        // "Unpair this device" on the device itself
          delete this.st().devices[devId]; this.sessions.delete(devId); this.o.save();
          await this._syncAllow().catch(() => {}); this._changed();
          break;
        default: await reply({ t: 'err', error: 'This version of Seal Chat does not know "' + String(m.t).slice(0, 20) + '"' });
      }
    } catch (e) { await reply({ t: 'err', error: e.message, tmp: m.tmp }); }
  }

  /** No device open any more → go back to idle checks straight away. */
  _quietCheck() { if (![...this.sessions.keys()].some(id => this._sessionAlive(id)) && !this.pairing) this.activeUntil = Math.min(this.activeUntil, Date.now() + (this.o.quietMs || 20e3)); }

  /* =================================================================
   * 7. SENDING TO DEVICES
   * ================================================================= */
  _nextSeq() { this.outSeq = Math.max(Date.now() * 1000, this.outSeq + 1); return this.outSeq; }

  /** Seals and sends one message to a paired device (in order). */
  _send(devId, obj) {
    const d = this.st().devices[devId];
    if (!d) return Promise.resolve();
    const sealed = seal(unb64u(d.k), AAD.msg('c2d', devId), { ...obj, s: this._nextSeq() });
    return this._sendRaw('d:' + devId, [sealed]);
  }

  _sendRaw(to, items) {
    const prev = this.sendChains.get(to) || Promise.resolve();
    const next = prev.catch(() => {}).then(() => this._call('send', { to, items }));
    this.sendChains.set(to, next);
    next.finally(() => { if (this.sendChains.get(to) === next) this.sendChains.delete(to); }).catch(() => {});
    return next;
  }

  /** Live update for every device that has the web interface open right now. */
  push(obj) {
    if (this.mode !== 'active') return;
    for (const id of this.sessions.keys()) if (this._sessionAlive(id)) this._send(id, obj).catch(e => this.emit('log', 'web access push: ' + e.message));
  }
  hasViewers() { return this.mode === 'active' && [...this.sessions.keys()].some(id => this._sessionAlive(id)); }
}

module.exports = { WebAccess, parseLink, seal, open, AAD, pairSecrets, deviceSecrets, b64u, unb64u, sha256hex };
