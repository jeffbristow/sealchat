/* =====================================================================
 * Seal Chat — updater.js   (checking for and downloading updates, 1.3.0)
 * ---------------------------------------------------------------------
 * How it works:
 *   1. Seal Chat asks the website which version is newest:
 *        https://jeffbristow.com/sealchat/update.php   (JSON)
 *      → { version, url, size, sha256, notes, released }
 *   2. If that version is higher than the one running, you're asked
 *      whether to download and install it.
 *   3. The update file (.sealchat) and its signature (.sealchat.sig) are
 *      downloaded. Seal Chat installs it ONLY if:
 *        - the signature was made with Seal Chat's private signing key
 *          (its public half is built into the app, below), and
 *        - the file's SHA-256 and version match what was signed.
 *      So even someone who took over the website could not push a fake
 *      update — they don't have the signing key.
 *   4. The verified file goes to the updates folder; bootstrap.js runs it
 *      on the next start (same as "Install update file…").
 *
 * By default all of this goes THROUGH TOR, so the website never sees
 * your IP address (a setting can switch that off if a network needs it).
 *
 * Sections:
 *   1. Signing key + version compare
 *   2. HTTPS GET (through Tor, or direct)
 *   3. Check
 *   4. Download + verify
 * ===================================================================== */

const fs = require('fs');
const path = require('path');
const https = require('https');
const tls = require('tls');
const crypto = require('crypto');
const { socksRaw } = require('./wire');

/* =================================================================
 * 1. SIGNING KEY + VERSIONS
 * Only update files signed with the matching private key are installed.
 * ================================================================= */
const UPDATE_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAzEcesiPus1IIakjsDR1oHhXjObb/7SqFeJDXS5ciyYY=
-----END PUBLIC KEY-----`;

const DEFAULT_CHECK_URL = 'https://jeffbristow.com/sealchat/update.php';

/** What is signed: name of the app, version and the file's SHA-256. */
const signedText = (version, sha256) => `sealchat-update-v1|${version}|${String(sha256).toLowerCase()}`;

function verifySignature(version, sha256, sigB64, publicKeyPem = UPDATE_PUBLIC_KEY) {
  try {
    return crypto.verify(null, Buffer.from(signedText(version, sha256)), crypto.createPublicKey(publicKeyPem), Buffer.from(String(sigB64), 'base64'));
  } catch { return false; }
}

function cmpVersion(a, b) {
  const pa = String(a).split('.').map(n => parseInt(n, 10) || 0), pb = String(b).split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0 ? 1 : -1; }
  return 0;
}

/* =================================================================
 * 2. HTTPS GET
 * opts: { socksPort (null = direct), maxBytes, onProgress(done,total), timeoutMs }
 * Resolves Buffer, or streams to opts.toFile and resolves its path.
 * ================================================================= */
function httpsGet(url, opts = {}, redirects = 0) {
  let u;
  try { u = new URL(url); } catch { return Promise.reject(new Error('Bad update address')); }
  if (u.protocol !== 'https:' && !opts.allowHttp) return Promise.reject(new Error('Update addresses must start with https://'));
  const port = Number(u.port) || (u.protocol === 'https:' ? 443 : 80);
  // through Tor: open a SOCKS connection first, then TLS on top of it
  const sockP = opts.socksPort
    ? socksRaw(opts.socksPort, u.hostname, port, 90000).then(raw => {
      raw.on('error', () => {});   // errors are reported through the request instead
      if (u.protocol !== 'https:') return raw;
      const t = tls.connect({ socket: raw, servername: require('net').isIP(u.hostname) ? undefined : u.hostname, ca: opts.ca });
      t.on('error', () => {});
      return t;
    })
    : Promise.resolve(null);
  return sockP.then(sock => new Promise((resolve, reject) => {
    const lib = u.protocol === 'https:' ? https : require('http');
    const reqOpts = {
      method: 'GET', hostname: u.hostname, port, path: u.pathname + u.search,
      headers: { 'User-Agent': 'SealChat-Updater', 'Accept': '*/*', 'Cache-Control': 'no-cache', 'Connection': 'close' },
      timeout: opts.timeoutMs || 60000, ca: opts.ca
    };
    // 1.4.1 FIX: the request must use the socket that goes through Tor. (Before, "agent: false"
    // made Node ignore createConnection and connect DIRECTLY — the Tor socket was opened but unused.)
    // A one-off agent whose createConnection hands over our Tor socket is always honoured.
    if (sock) { const A = new (u.protocol === 'https:' ? https : require('http')).Agent({ keepAlive: false }); A.createConnection = () => sock; reqOpts.agent = A; }
    const req = lib.request(reqOpts, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        if (redirects >= 4) return reject(new Error('Too many redirects'));
        return resolve(httpsGet(new URL(res.headers.location, url).toString(), opts, redirects + 1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`The update server answered ${res.statusCode}`)); }
      const total = Number(res.headers['content-length']) || 0;
      const max = opts.maxBytes || 10 * 1024 * 1024;
      if (total > max) { res.destroy(); return reject(new Error('Download is larger than expected')); }
      let done = 0;
      const out = opts.toFile ? fs.createWriteStream(opts.toFile, { mode: 0o600 }) : null;
      const chunks = [];
      res.on('data', d => {
        done += d.length;
        if (done > max) { res.destroy(new Error('Download is larger than expected')); return; }
        if (out) out.write(d); else chunks.push(d);
        if (opts.onProgress) opts.onProgress(done, total);
      });
      res.on('error', e => { if (out) out.destroy(); reject(e); });
      res.on('end', () => {
        if (!res.complete) return reject(new Error('Download was cut off'));
        if (out) out.end(() => resolve(opts.toFile)); else resolve(Buffer.concat(chunks));
      });
    });
    req.on('timeout', () => req.destroy(new Error('The update server did not answer in time')));
    req.on('error', e => reject(new Error(friendlyNetError(e, !!opts.socksPort))));
    req.end();
  }), e => { throw new Error(friendlyNetError(e, true)); });
}

function friendlyNetError(e, viaTor) {
  const m = e && e.message || String(e);
  if (/ENOTFOUND|EAI_AGAIN/.test(m)) return 'Could not find the update server (no internet?)';
  if (/certificate|CERT_|self signed/i.test(m)) return 'The update server\'s security certificate is not valid';
  if (viaTor && /contact|reach|Tor|SOCKS|timed out/i.test(m)) return 'Could not reach the update server through Tor (' + m.replace(/^Could not reach contact:?\s*/, '') + '). If this keeps happening, turn off "Check through Tor" in Settings.';
  return m;
}

/* =================================================================
 * 3 + 4. UPDATER
 * ================================================================= */
class Updater {
  /**
   * @param {object} o { currentVersion, updatesDir, settings() , socksPort() → number|null, publicKey, ca, log }
   */
  constructor(o) {
    this.o = o;
    this.state = { checking: false, available: null, lastCheck: null, error: null, downloading: false, progress: 0, ready: null };
  }

  checkUrl() { return (this.o.settings().updateUrl || '').trim() || DEFAULT_CHECK_URL; }
  _net() {
    const viaTor = this.o.settings().updateViaTor !== false;
    const socksPort = viaTor ? this.o.socksPort() : null;
    if (viaTor && !socksPort) throw new Error('Waiting for Tor to connect before checking for updates');
    return { socksPort, ca: this.o.ca, allowHttp: !!this.o.allowHttp };
  }

  /** Asks the website for the newest version. Resolves state.available (or null). */
  async check() {
    if (this.state.checking) return this.state;
    this.state.checking = true; this.state.error = null;
    try {
      const body = await httpsGet(this.checkUrl(), { ...this._net(), maxBytes: 256 * 1024, timeoutMs: 90000 });
      let info;
      try { info = JSON.parse(body.toString('utf8')); } catch { throw new Error('The update server sent something unexpected'); }
      this.state.lastCheck = Date.now();
      const v = String(info.version || '');
      if (!/^\d+(\.\d+){1,3}$/.test(v) || !info.url) { this.state.available = null; return this.state; }
      const url = new URL(String(info.url), this.checkUrl()).toString();
      if (cmpVersion(v, this.o.currentVersion) > 0) {
        this.state.available = {
          version: v, url,
          size: String(info.size || '').slice(0, 20),
          sha256: /^[0-9a-f]{64}$/i.test(info.sha256 || '') ? String(info.sha256).toLowerCase() : null,
          notes: (Array.isArray(info.notes) ? info.notes : String(info.notes || '').split(/\r?\n/)).map(s => String(s).trim()).filter(Boolean).slice(0, 30).map(s => s.slice(0, 300)),
          released: String(info.released || '').slice(0, 20),
          skipped: this.o.settings().skipVersion === v
        };
      } else this.state.available = null;
      return this.state;
    } catch (e) {
      this.state.error = e.message;
      throw e;
    } finally { this.state.checking = false; }
  }

  /**
   * Downloads the available update + its signature, verifies both, and puts
   * it where bootstrap.js picks it up. Resolves { version }.
   */
  async downloadAndInstall(onProgress) {
    const a = this.state.available;
    if (!a) throw new Error('No update available');
    if (this.state.downloading) throw new Error('Already downloading');
    this.state.downloading = true; this.state.progress = 0; this.state.error = null;
    const dir = this.o.updatesDir;
    fs.mkdirSync(dir, { recursive: true });
    const tmp = path.join(dir, 'incoming-' + Date.now() + '.tmp');
    try {
      const net = this._net();
      // a) signature first (small) — no point downloading a file we'd refuse
      let sigInfo;
      try { sigInfo = JSON.parse((await httpsGet(a.url + '.sig', { ...net, maxBytes: 16 * 1024 })).toString('utf8')); }
      catch (e) { throw new Error('The update has no valid signature file (' + e.message + '). Not installed.'); }
      if (String(sigInfo.version) !== a.version) throw new Error('The signature is for a different version. Not installed.');
      if (!/^[0-9a-f]{64}$/.test(String(sigInfo.sha256 || ''))) throw new Error('The signature file is damaged. Not installed.');
      if (!verifySignature(sigInfo.version, sigInfo.sha256, sigInfo.sig, this.o.publicKey)) throw new Error('The update\'s signature is NOT valid — it was not made by the Seal Chat signing key. Not installed.');

      // b) the file itself
      await httpsGet(a.url, { ...net, toFile: tmp, maxBytes: 300 * 1024 * 1024, timeoutMs: 120000, onProgress: (d, t) => { this.state.progress = t ? d / t : 0; if (onProgress) onProgress(d, t); } });
      const sha = crypto.createHash('sha256').update(fs.readFileSync(tmp)).digest('hex');
      if (sha !== String(sigInfo.sha256).toLowerCase()) throw new Error('The downloaded file does not match its signature (damaged or changed). Not installed.');

      // c) same checks as "Install update file…"
      const { readPackageJson } = require('./asarinfo');
      const pkg = readPackageJson(tmp);
      if (pkg.name !== 'sealchat' || !pkg.__hasMain) throw new Error('That is not a Seal Chat update');
      if (pkg.version !== a.version) throw new Error('The file contains version ' + pkg.version + ', not ' + a.version);
      if (cmpVersion(pkg.version, this.o.currentVersion) <= 0) throw new Error('You already have this version');
      const finalPath = path.join(dir, 'sealchat-' + pkg.version + '.asar');
      try { fs.unlinkSync(finalPath); } catch { /* none */ }
      fs.renameSync(tmp, finalPath);
      try { const badFile = path.join(dir, 'bad-versions.json'); fs.writeFileSync(badFile, JSON.stringify(JSON.parse(fs.readFileSync(badFile, 'utf8')).filter(v => v !== pkg.version))); } catch { /* none */ }
      this.state.ready = pkg.version;
      return { version: pkg.version };
    } catch (e) {
      try { fs.unlinkSync(tmp); } catch { /* none */ }
      this.state.error = e.message;
      throw e;
    } finally { this.state.downloading = false; }
  }
}

module.exports = { Updater, verifySignature, signedText, cmpVersion, httpsGet, UPDATE_PUBLIC_KEY, DEFAULT_CHECK_URL };
