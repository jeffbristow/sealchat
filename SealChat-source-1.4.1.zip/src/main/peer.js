/* =====================================================================
 * Seal Chat — peer.js   (the chat engine, 1.0.0)
 * ---------------------------------------------------------------------
 * Everything between "you pressed Send" and "it appeared on their PC":
 *
 *   YOUR SEAL CHAT ID   sealchat:<56-letter onion address>:<40-digit key fingerprint>
 *                       Share it with people you want to chat with. The
 *                       fingerprint inside it means nobody can pretend to
 *                       be you, even if they could somehow take over the address.
 *
 *   ADDING A CONTACT    Paste their ID → Seal Chat connects to their .onion,
 *                       fetches their public key, checks it matches the
 *                       fingerprint in the ID, then sends a signed + encrypted
 *                       contact request. When they accept, both of you can chat.
 *
 *   SENDING             Messages are signed and encrypted (PGP), then handed
 *                       straight to the contact's PC over Tor. Their PC
 *                       confirms it stored the message → "Delivered" ✓.
 *                       When they read it (if read receipts are on) → ✓✓.
 *
 *   OFFLINE CONTACTS    Messages wait in your Outbox. Seal Chat retries on a
 *                       schedule (20 s, 1, 2, 5, 10, then every 15 minutes)
 *                       and immediately whenever that contact's Seal Chat
 *                       starts up or contacts you. Nothing is stored on any
 *                       server — a message only travels when both PCs are on.
 *
 * Frames on the wire (see wire.js) — "box" is always a PGP-sealed block:
 *   hello   {onion, fp}            first frame on every connection
 *   welcome {onion, fp}            reply to hello
 *   getkey  → key {armored}        fetch the other side's public key
 *   req     {key, box}  → ok|no    contact request
 *   msg     {id, box}   → ack|nack chat message / receipt / accept
 *
 * FILES (1.1.0)       A file is sent as an "offer" (name, size, type, its own
 *                       random key, a small preview for photos) inside a normal
 *                       signed + encrypted message. The receiver's PC then
 *                       PULLS the encrypted pieces (see files.js) over the same
 *                       proven connection, a window at a time, and can resume
 *                       from the last good piece after any interruption.
 *                       Small files download by themselves; bigger ones ask.
 *     get   {id, g, i, n}  → n binary "piece" frames tagged "<id>/<g>", or gone {id}
 *     stop  {id, g}        → the sender drops what's left of that request
 *     (g = a new number for every attempt, so leftovers of an earlier,
 *      paused or broken attempt are recognised and ignored)
 *
 * PROFILE (1.2.0)     Your name and — if you choose to share it — your picture
 *                       go to each contact as a signed + encrypted "profile"
 *                       message, again whenever you change them. Contacts can
 *                       show it or pick their own picture for you.
 *
 * Sections:
 *   1. IDs (parse / format)
 *   2. Peer class setup + listener (incoming connections)
 *   3. Handling incoming frames
 *   4. Contacts: add, accept, decline, block, remove
 *   5. Messages: send, read receipts, history
 *   6. Delivery engine (outbox, retries, connections)
 *   7. Helpers
 * ===================================================================== */

const net = require('net');
const crypto = require('crypto');
const { EventEmitter } = require('events');
const { FrameSocket, socksConnect } = require('./wire');
const { describePublic } = require('./identity');
const { piecesFor, openPiece, SLOT, safeName, isRisky } = require('./files');

const PROTO = 1;
const VPORT = 80;                                           // port on the .onion side
const RETRY = [20e3, 60e3, 120e3, 300e3, 600e3, 900e3];     // outbox retry schedule
const MAX_TEXT = 10000;                                     // characters per message
const MAX_PENDING_REQUESTS = 50;
const IDLE_OUT = 2 * 60e3, IDLE_IN = 3 * 60e3;
const MAX_FILE = 4 * 1024 ** 3;                             // hard ceiling for any offer (4 GB)
const WINDOW = 16;                                          // pieces in flight per download (4 MB)
const DL_RETRY = [15e3, 45e3, 120e3, 300e3, 600e3, 900e3];  // download retry schedule
const fileKey = (contactId, msgId) => contactId + '|' + msgId;

/* =================================================================
 * 1. IDS
 * ================================================================= */
function formatId(onion, fp) { return `sealchat:${onion}:${String(fp).toUpperCase()}`; }

/** Accepts the ID with or without spaces/line breaks, or "<onion>.onion <FP>". */
function parseId(text) {
  const t = String(text || '').replace(/\s+/g, '').replace(/\.onion/gi, '').toLowerCase();
  const m = /^(?:sealchat:)?([a-z2-7]{56})[:/#]?([0-9a-f]{40}|[0-9a-f]{64})$/.exec(t);
  if (!m) throw new Error('That is not a Seal Chat ID. It looks like: sealchat:<56 letters/digits>:<40-digit fingerprint>');
  if (!/d$/.test(m[1])) throw new Error('That .onion address is not valid (check for a typo)');
  return { onion: m[1], fp: m[2].toUpperCase() };
}

const newId = () => crypto.randomBytes(12).toString('hex');
/** What a caller signs to prove who it is (one-time nonce + both addresses). */
const authText = (nonce, serverOnion, clientOnion, clientFp) => `sealchat-auth-v1|${nonce}|${serverOnion}|${clientOnion}|${String(clientFp).toUpperCase()}`;

/* =================================================================
 * 2. PEER
 * ================================================================= */
class Peer extends EventEmitter {
  /**
   * @param {object} o { store, identity, tor, log }
   */
  constructor(o) {
    super();
    this.store = o.store;
    this.id = o.identity;
    this.tor = o.tor;
    this.log = o.log || (() => {});
    this.server = null;
    this.port = 0;
    this.onion = null;
    this.out = new Map();          // contactId -> { busy, connecting, kick } (delivery in progress)
    this.links = new Map();        // contactId -> FrameSocket proven to be that contact (either direction)
    this.sched = new Map();        // contactId -> { next, tries }
    this.inbound = new Set();
    this.tick = null;
    this.running = false;
    this.files = o.files;          // FileVault (1.1.0)
    this.dl = new Map();           // "contact|msg" -> { running, next, tries, stop }
    this.lastEmit = new Map();     // progress-event throttling
  }

  get me() { return { onion: this.onion, fp: this.id.fp }; }
  myId() { return this.onion && this.id.fp ? formatId(this.onion, this.id.fp) : null; }

  /** Starts listening and publishes the .onion address. Tor must be connected. */
  async start() {
    if (this.running) return;
    this.server = net.createServer(s => this._incoming(s));
    this.server.maxConnections = 40;
    await new Promise((res, rej) => { this.server.once('error', rej); this.server.listen(0, '127.0.0.1', res); });
    this.port = this.server.address().port;
    const v = this.store.vault;
    const r = await this.tor.publish(v.onionKey || null, this.port, VPORT);
    if (!v.onionKey) { v.onionKey = r.key; this.store.saveVault(); }
    this.onion = r.onion;
    this.running = true;
    this._recoverFiles();
    this.tick = setInterval(() => this._tick(), 5000);
    // say hello to everyone: anyone holding messages for us sends them now
    for (const c of this.store.contacts()) {
      if (c.status === 'blocked') continue;
      this.sched.set(c.id, { next: Date.now() + 500 + Math.random() * 3000, tries: 0, hello: true });
    }
    this.emit('status');
  }

  async stop() {
    this.running = false;
    clearInterval(this.tick); this.tick = null;
    for (const l of this.links.values()) l.destroy();
    this.links.clear();
    this.out.clear();
    for (const s of this.inbound) s.destroy();
    this.inbound.clear();
    if (this.server) await new Promise(r => this.server.close(() => r()));
    this.server = null;
    try { await this.tor.unpublish(); } catch { /* ignore */ }
    this.store.flush();
  }

  _incoming(sock) {
    const fsk = new FrameSocket(sock);
    this.inbound.add(fsk);
    fsk.setIdle(IDLE_IN);
    fsk.on('close', () => this.inbound.delete(fsk));
    this._attach(fsk, { hello: null, authed: null, outbound: false });
  }

  /**
   * Frame handling for any connection. Connections work both ways: once a
   * contact has proven who they are, either side can send messages over it.
   */
  _attach(fsk, st) {
    st.frames = 0; st.since = Date.now();
    fsk.on('error', () => {});
    fsk.on('close', () => { if (st.authed && this.links.get(st.authed) === fsk) this.links.delete(st.authed); });
    fsk.on('frame', f => {
      // simple flood protection: 600 frames per minute per connection
      if (f.t !== 'piece' && ++st.frames > 600) { if (Date.now() - st.since < 60e3) return fsk.destroy(); st.frames = 0; st.since = Date.now(); }
      this._frame(fsk, st, f).catch(e => { this.log('frame error: ' + e.message); try { fsk.send({ t: 'nack', id: f.id, why: 'bad' }); } catch { /* closed */ } });
    });
  }

  /* =================================================================
   * 3. INCOMING FRAMES
   * ================================================================= */
  async _frame(fsk, st, f) {
    switch (f.t) {
      case 'hello': {
        if (st.outbound || st.hello) return;
        if (!/^[a-z2-7]{56}$/.test(f.onion || '') || !/^[0-9A-F]{40,64}$/.test(f.fp || '')) return fsk.destroy();
        st.hello = { onion: f.onion, fp: f.fp };
        st.nonce = crypto.randomBytes(24).toString('hex');
        fsk.send({ t: 'welcome', v: PROTO, onion: this.onion, fp: this.id.fp, nonce: st.nonce });
        return;
      }
      case 'auth': {
        // the caller proves it holds the private key of a contact (signature over our
        // one-time nonce + both addresses) — then this connection counts as theirs
        if (st.outbound || !st.hello || st.authed) return;
        const c = this.store.contact(st.hello.fp);
        let good = false;
        if (c && c.publicKey && c.status !== 'blocked' && c.status !== 'pending-in') {
          good = await this.id.verifyText(authText(st.nonce, this.onion, st.hello.onion, st.hello.fp), f.sig, c.publicKey);
        }
        fsk.send({ t: good ? 'authok' : 'authno' });
        if (!good) return;
        st.authed = c.id;
        if (c.onion !== st.hello.onion) c.onion = st.hello.onion;      // proven by their signature
        c.lastSeen = Date.now(); this.store.putContact(c);
        this.links.set(c.id, fsk);
        // they're online: if we were still dialling their old circuit, use this one instead
        const slot = this.out.get(c.id);
        if (slot && slot.connecting) { slot.kick = true; slot.connecting.destroy(); }
        this._soon(c.id, 100);
        this._dlKick(c.id);
        this.emit('contacts');
        return;
      }
      case 'getkey':
        return fsk.send({ t: 'key', armored: this.id.pubArmored });
      case 'req':
        return this._onRequest(fsk, st, f);
      case 'msg':
        return this._onMsg(fsk, st, f);
      case 'get':
        return this._onGet(fsk, st, f);
      case 'stop':
        (st.stopped = st.stopped || new Set()).add(String(f.id) + '/' + String(f.g));
        return;
      case 'piece': case 'gone':
        return;   // answers to our own downloads — read by _download()
      case 'bye':
        return fsk.end();
      default:
        return; // unknown frame types are ignored (newer versions)
    }
  }

  /* ---------- contact request arriving ---------- */
  async _onRequest(fsk, st, f) {
    const reply = (ok, why) => fsk.send(ok ? { t: 'ok', id: f.id } : { t: 'no', id: f.id, why });
    if (!st.hello) return reply(false, 'hello first');
    if (!this.id.unlocked) return reply(false, 'locked');
    if (this.store.settings.allowRequests === false) return reply(false, 'not accepting requests');
    let info;
    try { info = await describePublic(String(f.key || '')); } catch { return reply(false, 'bad key'); }
    if (info.fp !== st.hello.fp) return reply(false, 'key mismatch');
    if (!info.canEncrypt) return reply(false, 'key cannot encrypt');
    const r = await this.id.open(f.box, info.armored);
    const o = r.obj || {};
    if (!r.valid || o.k !== 'req' || o.to !== this.id.fp || !o.from || o.from.fp !== info.fp || o.from.onion !== st.hello.onion) return reply(false, 'bad request');

    let c = this.store.contact(info.fp);
    if (c && c.status === 'blocked') return reply(false, 'blocked');
    if (c && (c.status === 'accepted' || c.status === 'pending-out')) {
      // we know them already (or we asked them too): accept automatically — after
      // checking their address really belongs to that key
      c.publicKey = info.armored; c.keyName = info.name;
      if (o.avatar !== undefined) c.sharedAvatar = cleanAvatar(o.avatar);
      c.onion = st.hello.onion;          // signed by their key: a new address (new PC) is fine
      if (c.status === 'pending-out') { c.status = 'accepted'; c.acceptedAt = Date.now(); }
      this._queueCtl(c.id, { k: 'accept' });
      this._maybeShareProfile(c);
      this.store.putContact(c);
      reply(true);
      this.emit('contacts');
      this._soon(c.id, 200);
      return;
    }
    if (!c) {
      const pending = this.store.contacts().filter(x => x.status === 'pending-in').length;
      if (pending >= MAX_PENDING_REQUESTS) return reply(false, 'too many requests');
    }
    c = {
      ...(c || {}),
      id: info.fp, fp: info.fp, onion: st.hello.onion, publicKey: info.armored,
      keyName: info.name, name: String(o.from.name || info.name || '').slice(0, 80),
      note: String(o.note || '').slice(0, 500), status: 'pending-in', sharedAvatar: cleanAvatar(o.avatar),
      addedAt: (c && c.addedAt) || Date.now(), lastSeen: Date.now(), verified: false
    };
    this.store.putContact(c);
    reply(true);
    this.emit('contacts');
    this.emit('request', c);
  }

  /* ---------- chat message / receipt / accept arriving ---------- */
  async _onMsg(fsk, st, f) {
    const nack = why => fsk.send({ t: 'nack', id: f.id, why });
    if (!st.hello) return nack('hello first');
    const c = this.store.contact(st.hello.fp);
    if (!c || !c.publicKey) return nack('unknown');
    if (c.status === 'blocked') return nack('blocked');
    if (c.status === 'pending-in') return nack('pending');
    if (!this.id.unlocked) return nack('locked');
    const r = await this.id.open(f.box, c.publicKey);
    const o = r.obj || {};
    if (!r.valid || o.to !== this.id.fp || !o.from || o.from.fp !== c.fp) return nack('bad');
    if (o.from.onion && o.from.onion !== c.onion) {
      // contact moved to a new address (e.g. new PC, same key) — the signature proves it's them
      c.onion = o.from.onion;
    }
    c.lastSeen = Date.now();

    switch (o.k) {
      case 'accept':
        if (c.status === 'pending-out') { c.status = 'accepted'; c.acceptedAt = Date.now(); this.emit('accepted', c); }
        break;
      case 'text': {
        if (c.status === 'pending-out') { c.status = 'accepted'; c.acceptedAt = Date.now(); } // their message implies they accepted
        const chat = this.store.chat(c.id);
        if (!chat.messages.some(m => m.id === o.id && m.dir === 'in')) {
          const msg = { id: String(o.id).slice(0, 40), dir: 'in', text: String(o.text || '').slice(0, MAX_TEXT), ts: Number(o.ts) || Date.now(), at: Date.now(), read: false };
          chat.messages.push(msg);
          c.unread = (c.unread || 0) + 1;
          c.lastAt = msg.at; c.lastText = msg.text.slice(0, 120); c.lastDir = 'in';
          this.store.saveChat(c.id);
          this.emit('message', { contactId: c.id, msg });
        }
        break;
      }
      case 'read': {
        const chat = this.store.chat(c.id);
        const ids = new Set((Array.isArray(o.ids) ? o.ids : []).slice(0, 500));
        let n = 0;
        for (const m of chat.messages) if (m.dir === 'out' && ids.has(m.id) && m.state !== 'read') { m.state = 'read'; m.readAt = Date.now(); n++; }
        if (n) { this.store.saveChat(c.id); this.emit('receipts', { contactId: c.id }); }
        break;
      }
      case 'file': {
        if (c.status === 'pending-out') { c.status = 'accepted'; c.acceptedAt = Date.now(); }
        const chat = this.store.chat(c.id);
        if (chat.messages.some(m => m.id === o.id && m.dir === 'in')) break;
        const f = checkOffer(o);
        if (!f) return nack('bad');
        // program files never download by themselves, whatever their size
        const auto = !isRisky(f.name) && f.size <= (Number(this.store.settings.autoDownloadMB ?? 25) * 1024 * 1024);
        const msg = { id: String(o.id).slice(0, 40), dir: 'in', kind: 'file', text: String(o.text || '').slice(0, MAX_TEXT), file: f,
          ts: Number(o.ts) || Date.now(), at: Date.now(), read: false, transfer: { state: auto ? 'queued' : 'offered', got: 0 } };
        chat.messages.push(msg);
        c.unread = (c.unread || 0) + 1;
        c.lastAt = msg.at; c.lastText = '📎 ' + f.name; c.lastDir = 'in';
        this.store.saveChat(c.id);
        this.emit('message', { contactId: c.id, msg });
        if (auto) this._dlSoon(c.id, msg.id, 500);
        break;
      }
      case 'filedone': {
        const m = this.store.chat(c.id).messages.find(x => x.id === o.fid && x.dir === 'out' && x.kind === 'file');
        if (m) {
          m.transfer = { ...(m.transfer || {}), state: o.status === 'done' ? 'done' : 'declined', at: Date.now() };
          this.store.saveChat(c.id);
          this.emit('transfer', { contactId: c.id, id: m.id, transfer: m.transfer });
        }
        break;
      }
      case 'profile':
        if (o.name) c.name = String(o.name).slice(0, 80);
        if ('avatar' in o) { c.sharedAvatar = cleanAvatar(o.avatar); c.sharedAvatarAt = Date.now(); }
        break;
      case 'ping':
        break;
      default:
        // something from a newer Seal Chat that this version can't show: say so
        // (instead of "delivered"), so the sender knows to tell us to update
        return nack('unsupported');
    }
    this._maybeShareProfile(c);
    this.store.putContact(c);
    this.store.flush();                 // safely on disk BEFORE we tell them it arrived
    fsk.send({ t: 'ack', id: f.id });
    this.emit('contacts');
    this._soon(c.id, 300); // they're online: deliver anything waiting for them
    this._dlKick(c.id);    // …and fetch any files we were waiting for
  }

  /* =================================================================
   * 4. CONTACTS
   * ================================================================= */
  /** Add someone by their Seal Chat ID. The request is sent in the background. */
  addContact(idText, { nick, note } = {}) {
    const { onion, fp } = parseId(idText);
    if (fp === this.id.fp) throw new Error('That is your own Seal Chat ID');
    let c = this.store.contact(fp);
    if (c && c.status === 'accepted') throw new Error('That person is already in your contacts');
    if (c && c.status === 'pending-in') { c.onion = onion; this.store.putContact(c); return this.accept(fp); }
    c = { ...(c || {}), id: fp, fp, onion, nick: nick ? String(nick).slice(0, 80) : (c && c.nick) || '', note: String(note || '').slice(0, 500),
      status: 'pending-out', requested: false, addedAt: Date.now(), verified: false, publicKey: (c && c.publicKey) || null };
    this.store.putContact(c);
    this.emit('contacts');
    this._soon(fp, 0);
    return c;
  }

  accept(id) {
    const c = this.store.contact(id);
    if (!c || c.status !== 'pending-in') throw new Error('No request from that contact');
    // Their address is double-checked before anything is sent: we fetch the key
    // from that .onion and it must be the same key that signed the request.
    c.status = 'accepted'; c.acceptedAt = Date.now(); c.addressChecked = false;
    this._queueCtl(id, { k: 'accept' });
    this._maybeShareProfile(c);
    this.store.putContact(c);
    this.emit('contacts');
    this._soon(id, 0);
    return c;
  }

  decline(id) {
    const c = this.store.contact(id);
    if (c && c.status === 'pending-in') this.store.removeContact(id);
    this.emit('contacts');
  }

  block(id) {
    const c = this.store.contact(id);
    if (!c) return;
    c.status = 'blocked'; c.blockedAt = Date.now();
    this.store.putContact(c);
    this._dropCtl(id);
    this.emit('contacts');
  }

  unblock(id) {
    const c = this.store.contact(id);
    if (!c || c.status !== 'blocked') return;
    c.status = c.publicKey ? 'accepted' : 'pending-out';
    this.store.putContact(c);
    this.emit('contacts');
    this._soon(id, 0);
  }

  remove(id) {
    this._dropCtl(id);
    for (const m of this.store.chat(id).messages) if (m.kind === 'file') this._dropFile(id, m);
    const o = this.out.get(id); if (o && o.sock) o.sock.destroy();
    this.out.delete(id); this.sched.delete(id);
    this.store.removeContact(id);
    this.emit('contacts');
  }

  rename(id, nick) { const c = this.store.contact(id); if (c) { c.nick = String(nick || '').slice(0, 80); this.store.putContact(c); this.emit('contacts'); } }
  setVerified(id, v) { const c = this.store.contact(id); if (c) { c.verified = !!v; this.store.putContact(c); this.emit('contacts'); } }

  /* =================================================================
   * 5. MESSAGES
   * ================================================================= */
  send(id, text) {
    const c = this.store.contact(id);
    if (!c) throw new Error('Unknown contact');
    if (c.status === 'blocked') throw new Error('You blocked this contact');
    if (c.status === 'pending-in') throw new Error('Accept their request first');
    text = String(text || '').replace(/\r\n/g, '\n');
    if (!text.trim()) throw new Error('Nothing to send');
    if (text.length > MAX_TEXT) throw new Error(`Messages can be up to ${MAX_TEXT.toLocaleString()} characters`);
    const msg = { id: newId(), dir: 'out', text, ts: Date.now(), at: Date.now(), state: 'queued' };
    const chat = this.store.chat(id);
    chat.messages.push(msg);
    c.lastAt = msg.at; c.lastText = text.slice(0, 120); c.lastDir = 'out';
    this.store.saveChat(id);
    this.store.putContact(c);
    this._soon(id, 0);
    return msg;
  }

  /** Marks a chat as read; queues a read receipt if those are on. */
  markRead(id) {
    const c = this.store.contact(id);
    if (!c) return;
    const chat = this.store.chat(id);
    const ids = [];
    for (const m of chat.messages) if (m.dir === 'in' && !m.read) { m.read = true; ids.push(m.id); }
    if (ids.length) this.store.saveChat(id);
    if (c.unread) { c.unread = 0; this.store.putContact(c); }
    if (ids.length && this.store.settings.readReceipts !== false && c.status === 'accepted') {
      this._queueCtl(id, { k: 'read', ids });
      this._soon(id, 500);
    }
  }

  history(id) { return this.store.chat(id).messages; }

  deleteMessage(id, msgId) {
    const chat = this.store.chat(id);
    const i = chat.messages.findIndex(m => m.id === msgId);
    if (i >= 0) { const [m] = chat.messages.splice(i, 1); if (m.kind === 'file') this._dropFile(id, m); this.store.saveChat(id); }
  }

  clearChat(id) {
    const chat = this.store.chat(id);
    // keep messages still waiting to be sent
    const keep = m => m.dir === 'out' && (m.state === 'queued' || m.state === 'preparing');
    for (const m of chat.messages) if (!keep(m) && m.kind === 'file') this._dropFile(id, m);
    chat.messages = chat.messages.filter(keep);
    const c = this.store.contact(id); if (c) { c.lastText = ''; c.unread = 0; this.store.putContact(c); }
    this.store.saveChat(id);
  }

  retryNow(id) { const s = this.sched.get(id); if (s) s.tries = 0; this._soon(id, 0); }

  /** Counts for the window title / tray. */
  counts() {
    let unread = 0, queued = 0, requests = 0;
    for (const c of this.store.contacts()) {
      unread += c.unread || 0;
      if (c.status === 'pending-in') requests++;
    }
    for (const c of this.store.contacts()) queued += this.store.chat(c.id).messages.filter(m => m.state === 'queued').length;
    return { unread, queued, requests };
  }

  /* =================================================================
   * 6. DELIVERY ENGINE
   * ================================================================= */
  _queueCtl(id, item) {
    const v = this.store.vault;
    v.ctl = v.ctl || [];
    if (item.k === 'read') {
      const prev = v.ctl.find(x => x.to === id && x.k === 'read');
      if (prev) { prev.ids = [...new Set([...prev.ids, ...item.ids])].slice(-500); this.store.saveVault(); return; }
    }
    if (item.k === 'accept' && v.ctl.some(x => x.to === id && x.k === 'accept')) return;
    if (item.k === 'profile') v.ctl = v.ctl.filter(x => !(x.to === id && x.k === 'profile'));   // only the newest
    v.ctl.push({ ...item, id: newId(), to: id, ts: Date.now() });
    this.store.saveVault();
  }
  _dropCtl(id) { const v = this.store.vault; if (v.ctl) { v.ctl = v.ctl.filter(x => x.to !== id); this.store.saveVault(); } }

  _soon(id, ms) {
    const s = this.sched.get(id) || { tries: 0 };
    s.next = Math.min(s.next || Infinity, Date.now() + ms);
    this.sched.set(id, s);
    if (ms <= 0) setImmediate(() => this._tick());
  }

  _hasWork(c) {
    if (c.status === 'blocked' || c.status === 'pending-in') return false;
    if (c.status === 'pending-out' && !c.requested) return true;
    if ((this.store.vault.ctl || []).some(x => x.to === c.id)) return true;
    return this.store.chat(c.id).messages.some(m => m.dir === 'out' && m.state === 'queued');
  }

  _tick() {
    if (!this.running || !this.tor.ready) return;
    const now = Date.now();
    this._dlTick(now);
    for (const [id, s] of this.sched) {
      if (!s.next || s.next > now) continue;
      const c = this.store.contact(id);
      if (!c) { this.sched.delete(id); continue; }
      const o = this.out.get(id);
      if (o && o.busy) continue;
      if (!this._hasWork(c) && !s.hello) { this.sched.delete(id); continue; }
      s.next = 0;
      this._deliver(c, s).catch(e => this.log('deliver: ' + e.message));
    }
  }

  async _connection(c) {
    const have = this.links.get(c.id);
    if (have && !have.closed) return have;
    const slot = this.out.get(c.id);
    const sock = await socksConnect(this.tor.socksPort, c.onion + '.onion', VPORT, undefined, raw => { if (slot) slot.connecting = raw; });
    if (slot) slot.connecting = null;
    sock.on('error', () => {});
    sock.setIdle(IDLE_OUT);
    const w = await sock.request({ t: 'hello', v: PROTO, onion: this.onion, fp: this.id.fp }, f => f.t === 'welcome', 60e3);
    if (String(w.fp).toUpperCase() !== c.fp) {
      sock.destroy();
      throw Object.assign(new Error('The key at that address does not match the fingerprint in their ID — check the ID with them'), { fatal: true });
    }
    // We dialled their .onion, so Tor guarantees who answered. Prove who WE are,
    // so they can send their messages back over this same connection.
    if (w.nonce && /^[0-9a-f]{48}$/.test(w.nonce)) {
      try {
        const sig = await this.id.signText(authText(w.nonce, c.onion, this.onion, this.id.fp));
        await sock.request({ t: 'auth', sig }, f => f.t === 'authok' || f.t === 'authno', 30e3);
      } catch { /* older/unknown: still fine for sending */ }
    }
    const st = { hello: { onion: c.onion, fp: c.fp }, authed: c.id, outbound: true };
    this._attach(sock, st);
    this.links.set(c.id, sock);
    return sock;
  }

  async _deliver(c, s) {
    const slot = this.out.get(c.id) || { sock: null, busy: false };
    slot.busy = true; this.out.set(c.id, slot);
    let ok = false, why = null;
    try {
      const sock = await this._connection(c);
      c.lastReached = Date.now(); c.lastError = null;
      s.hello = false;
      this._maybeShareProfile(c);

      // a) make sure we have their key, straight from their .onion
      if (!c.publicKey || c.status === 'pending-out' && !c.requested || c.addressChecked === false) {
        const k = await sock.request({ t: 'getkey' }, f => f.t === 'key', 60e3);
        const info = await describePublic(String(k.armored || ''));
        if (info.fp !== c.fp) throw Object.assign(new Error('Their key does not match the fingerprint in their ID — not added'), { fatal: true });
        c.publicKey = info.armored; c.keyName = info.name; c.addressChecked = true;
        if (!c.name) c.name = info.name;
      }

      // b) contact request
      if (c.status === 'pending-out' && !c.requested) {
        const id = newId();
        const prof = this.profile();
        const box = await this.id.sealFor(c.publicKey, { k: 'req', id, to: c.fp, from: { ...this.me, name: prof.name }, avatar: prof.avatar, note: c.note || '', ts: Date.now() });
        const r = await sock.request({ t: 'req', id, key: this.id.pubArmored, box }, f => (f.t === 'ok' || f.t === 'no') && f.id === id, 90e3);
        if (r.t === 'no') throw Object.assign(new Error('Request not accepted: ' + r.why), { why: r.why });
        c.requested = true; c.requestedAt = Date.now();
      }

      // c) control items (accept, read receipts) then queued messages, oldest first
      const v = this.store.vault;
      for (const item of (v.ctl || []).filter(x => x.to === c.id)) {
        if (item.k === 'accept' && c.status !== 'accepted') continue;
        const { to: _to, ver: _ver, ...payload } = item;
        await this._sendBox(sock, c, payload);
        if (item.k === 'profile') c.profileSent = item.ver;
        v.ctl = v.ctl.filter(x => x !== item);
        this.store.saveVault();
      }
      if (c.status === 'accepted' || c.status === 'pending-out') {
        const chat = this.store.chat(c.id);
        for (const m of chat.messages.filter(x => x.dir === 'out' && x.state === 'queued').slice(0, 100)) {
          if (m.kind === 'file') {
            if (!this.files || !this.files.isComplete(fileKey(c.id, m.id), m.file)) { m.state = 'failed'; m.transfer = { state: 'failed', err: 'The file is no longer on this PC' }; this.store.saveChat(c.id); continue; }
            const { name, size, mime, pieces, key, nonce, thumb } = m.file;
            try { await this._sendBox(sock, c, { k: 'file', id: m.id, text: m.text || '', ts: m.ts, file: { name, size, mime, pieces, key, nonce, thumb } }); }
            catch (e) {
              if (e.why !== 'unsupported' && e.why !== 'bad') throw e;
              m.state = 'failed'; m.transfer = { state: 'failed', err: `${c.nick || c.name || 'Your contact'} needs Seal Chat 1.1 or newer to receive files` };
              this.store.saveChat(c.id); this.emit('receipts', { contactId: c.id }); continue;
            }
            m.transfer = { ...(m.transfer || {}), state: 'waiting' };
          } else {
            await this._sendBox(sock, c, { k: 'text', id: m.id, text: m.text, ts: m.ts });
          }
          m.state = 'sent'; m.deliveredAt = Date.now();
          this.store.saveChat(c.id);
          this.emit('receipts', { contactId: c.id });
        }
      }
      ok = true;
    } catch (e) {
      why = e.why || e.message;
      c.lastError = e.message;
      if (e.fatal) { c.status = 'failed'; c.failReason = e.message; }
      if (e.code === 'UNREACHABLE') c.lastError = 'Offline — will keep trying';
      this.log(`deliver ${c.fp.slice(0, 8)}: ${e.message}`);
    } finally {
      slot.busy = false; slot.connecting = null;
      this.store.putContact(c);
      this.emit('contacts');
    }
    // schedule the next attempt
    if (ok && !this._hasWork(c)) { this.sched.delete(c.id); return; }
    if (ok) { s.tries = 0; s.next = Date.now() + 200; return; }
    if (slot.kick) { slot.kick = false; s.tries = 0; s.next = Date.now() + 500; return; }   // they just said hello: try again at once
    if (c.status === 'failed') { this.sched.delete(c.id); return; }
    const wait = why === 'pending' ? 120e3 : RETRY[Math.min(s.tries, RETRY.length - 1)];
    s.tries++;
    s.next = Date.now() + wait * (0.85 + Math.random() * 0.3);
  }

  async _sendBox(sock, c, payload) {
    const id = payload.id || newId();
    const box = await this.id.sealFor(c.publicKey, { ...payload, id, to: c.fp, from: this.me, ts: payload.ts || Date.now() });
    const r = await sock.request({ t: 'msg', id, box }, f => (f.t === 'ack' || f.t === 'nack') && f.id === id, 90e3);
    if (r.t === 'nack') {
      const msgs = { pending: 'Waiting for them to accept your request', unknown: 'They don\'t have you as a contact', blocked: 'Not delivered', locked: 'Their Seal Chat is locked', bad: 'They could not read the message', unsupported: 'Their Seal Chat needs updating to receive this' };
      throw Object.assign(new Error(msgs[r.why] || 'Not delivered (' + r.why + ')'), { why: r.why });
    }
  }

  /* =================================================================
   * 6b. PROFILE (1.2.0)
   * ================================================================= */
  /** What contacts get: your name, and your picture only if you share it. */
  profile() {
    const me = this.store.vault.me || {};
    return { name: this.store.settings.displayName || this.id.name || '', avatar: me.shareAvatar !== false && me.avatar ? me.avatar : null };
  }
  _profileVersion() { const p = this.profile(); return crypto.createHash('sha256').update(p.name + '|' + (p.avatar || '')).digest('hex').slice(0, 16); }

  /** Queues your current profile for a contact if they don't have it yet. */
  _maybeShareProfile(c) {
    if (!c || c.status !== 'accepted') return;
    const ver = this._profileVersion();
    if (c.profileSent === ver || (this.store.vault.ctl || []).some(x => x.to === c.id && x.k === 'profile' && x.ver === ver)) return;
    const p = this.profile();
    this._queueCtl(c.id, { k: 'profile', name: p.name, avatar: p.avatar, ver });
  }

  /** After you change your name or picture: send it to everyone. */
  shareProfileAll() {
    for (const c of this.store.contacts()) if (c.status === 'accepted') { this._maybeShareProfile(c); this._soon(c.id, 1000 + Math.random() * 4000); }
  }

  /* =================================================================
   * 7. FILES (1.1.0)
   * ================================================================= */
  /**
   * Sends a file. source: { path } or { buffer }; info: { name, mime, thumb, text }.
   * The message appears at once ("Preparing…") while the file is encrypted
   * into Seal Chat's storage; then its offer goes out like any message.
   */
  async sendFile(id, source, info, onAdded) {
    const c = this.store.contact(id);
    if (!c) throw new Error('Unknown contact');
    if (c.status === 'blocked') throw new Error('You blocked this contact');
    if (c.status === 'pending-in') throw new Error('Accept their request first');
    if (!this.files) throw new Error('File sending is not available');
    const size = source.buffer ? source.buffer.length : require('fs').statSync(source.path).size;
    const maxMB = Number(this.store.settings.maxFileMB ?? 2048);
    if (size > maxMB * 1024 * 1024) throw new Error(`"${info.name}" is ${fmtSize(size)}. The largest file you can send is ${fmtSize(maxMB * 1024 * 1024)} (Settings → Files).`);
    if (size > MAX_FILE) throw new Error('Files can be up to 4 GB');
    const msg = { id: newId(), dir: 'out', kind: 'file', text: String(info.text || '').slice(0, MAX_TEXT), ts: Date.now(), at: Date.now(), state: 'preparing',
      file: { name: safeName(info.name), size, mime: cleanMime(info.mime), pieces: piecesFor(size), thumb: cleanThumb(info.thumb) }, transfer: { state: 'preparing', done: 0 } };
    const chat = this.store.chat(id);
    chat.messages.push(msg);
    c.lastAt = msg.at; c.lastText = '📎 ' + msg.file.name; c.lastDir = 'out';
    this.store.saveChat(id); this.store.putContact(c);
    if (onAdded) onAdded(msg);
    try {
      const meta = await this.files.importFile(fileKey(id, msg.id), msg.id, source, (done, total) => this._progress(id, msg, { state: 'preparing', done, total }));
      Object.assign(msg.file, { key: meta.key, nonce: meta.nonce, pieces: meta.pieces, size: meta.size });
      msg.state = 'queued'; msg.transfer = { state: 'offered' };
    } catch (e) {
      msg.state = 'failed'; msg.transfer = { state: 'failed', err: 'Could not read the file: ' + e.message };
      this.files.remove(fileKey(id, msg.id));
    }
    this.store.saveChat(id);
    this.emit('transfer', { contactId: id, id: msg.id, transfer: msg.transfer, state: msg.state });
    if (msg.state === 'queued') this._soon(id, 0);
    return msg;
  }

  /** Receiver: start (or resume / retry) downloading a file. */
  download(id, msgId) {
    const m = this.store.chat(id).messages.find(x => x.id === msgId && x.dir === 'in' && x.kind === 'file');
    if (!m) throw new Error('File not found');
    if (m.transfer.state === 'done') return m;
    m.transfer = { ...m.transfer, state: 'queued', err: null };
    this.store.saveChat(id);
    const d = this.dl.get(fileKey(id, msgId)); if (d) d.tries = 0;
    this._dlSoon(id, msgId, 0);
    this.emit('transfer', { contactId: id, id: msgId, transfer: m.transfer });
    return m;
  }

  /** Receiver: pause a download (keeps what has arrived). */
  pauseDownload(id, msgId) {
    const m = this.store.chat(id).messages.find(x => x.id === msgId && x.dir === 'in' && x.kind === 'file');
    if (!m || m.transfer.state === 'done') return;
    m.transfer = { ...m.transfer, state: 'paused' };
    const d = this.dl.get(fileKey(id, msgId)); if (d) { d.stop = true; if (d.cancel) d.cancel(); }
    this.store.saveChat(id);
    this.emit('transfer', { contactId: id, id: msgId, transfer: m.transfer });
  }

  /** Receiver: say no to a file (the sender sees "Declined"). */
  declineFile(id, msgId) {
    const m = this.store.chat(id).messages.find(x => x.id === msgId && x.dir === 'in' && x.kind === 'file');
    if (!m) return;
    const d = this.dl.get(fileKey(id, msgId)); if (d) { d.stop = true; if (d.cancel) d.cancel(); }
    this.files.remove(fileKey(id, msgId));
    m.transfer = { state: 'declined', got: 0 };
    this.store.saveChat(id);
    this._queueCtl(id, { k: 'filedone', fid: msgId, status: 'declined' });
    this._soon(id, 500);
    this.emit('transfer', { contactId: id, id: msgId, transfer: m.transfer });
  }

  /** Where a finished file is, for showing / saving. */
  fileRef(id, msgId) {
    const m = this.store.chat(id).messages.find(x => x.id === msgId && x.kind === 'file');
    if (!m) throw new Error('File not found');
    const where = fileKey(id, msgId);
    if (!this.files.isComplete(where, m.file)) throw new Error(m.dir === 'in' ? 'The file has not finished downloading' : 'The file is no longer on this PC');
    return { where, msg: m, meta: m.file };
  }

  /** Removes the stored data of files older than `days` (0 = all); the messages stay. */
  freeFileSpace(days = 0) {
    const cutoff = Date.now() - days * 864e5;
    let n = 0;
    for (const c of this.store.contacts()) {
      const chat = this.store.chat(c.id); let changed = false;
      for (const m of chat.messages) {
        if (m.kind !== 'file' || m.at > cutoff || m.removed) continue;
        if (m.dir === 'out' && (m.state === 'queued' || m.state === 'preparing')) continue;
        const d = this.dl.get(fileKey(c.id, m.id)); if (d) d.stop = true;
        this.files.remove(fileKey(c.id, m.id));
        m.removed = true; m.transfer = { ...(m.transfer || {}), state: m.dir === 'in' && m.transfer && m.transfer.state !== 'done' ? 'paused' : (m.transfer || {}).state, got: 0 };
        changed = true; n++;
      }
      if (changed) this.store.saveChat(c.id);
    }
    return n;
  }

  _dropFile(id, m) {
    const d = this.dl.get(fileKey(id, m.id)); if (d) { d.stop = true; if (d.cancel) d.cancel(); }
    this.dl.delete(fileKey(id, m.id));
    if (this.files) this.files.remove(fileKey(id, m.id));
  }

  /** After a restart: "preparing" can't continue; running downloads resume. */
  _recoverFiles() {
    if (!this.files) return;
    for (const c of this.store.contacts()) {
      const chat = this.store.chat(c.id); let changed = false;
      for (const m of chat.messages) {
        if (m.kind !== 'file') continue;
        if (m.dir === 'out' && m.state === 'preparing') { m.state = 'failed'; m.transfer = { state: 'failed', err: 'Seal Chat closed before the file was ready — send it again' }; this.files.remove(fileKey(c.id, m.id)); changed = true; }
        if (m.dir === 'in' && (m.transfer.state === 'queued' || m.transfer.state === 'downloading')) { m.transfer.state = 'queued'; this._dlSoon(c.id, m.id, 3000 + Math.random() * 3000); changed = true; }
      }
      if (changed) this.store.saveChat(c.id);
    }
  }

  _progress(contactId, m, transfer) {
    m.transfer = { ...(m.transfer || {}), ...transfer };
    const k = fileKey(contactId, m.id), now = Date.now();
    if (now - (this.lastEmit.get(k) || 0) < 250 && transfer.state === (m.lastSentState || transfer.state)) return;
    this.lastEmit.set(k, now); m.lastSentState = transfer.state;
    this.emit('transfer', { contactId, id: m.id, transfer: m.transfer });
  }

  /* ---------- sender side: answering "get" ---------- */
  async _onGet(fsk, st, f) {
    const id = String(f.id || '');
    // only over a connection proven to be the contact the file was sent to
    const c = st.authed && this.store.contact(st.authed);
    const m = c && this.store.chat(c.id).messages.find(x => x.id === id && x.dir === 'out' && x.kind === 'file' && x.state !== 'preparing' && x.state !== 'failed');
    if (!m || !this.files || !this.files.isComplete(fileKey(c.id, id), m.file)) return fsk.send({ t: 'gone', id });
    const i = Number(f.i), n = Math.min(Number(f.n) || 1, WINDOW);
    const tag = id + '/' + String(f.g || 0).slice(0, 12);
    if (!Number.isInteger(i) || i < 0 || i >= m.file.pieces || n < 1) return fsk.send({ t: 'gone', id });
    // one connection serves its requests strictly in order
    st.serving = (st.serving || Promise.resolve()).then(async () => {
      for (let k = i; k < Math.min(i + n, m.file.pieces); k++) {
        if (fsk.closed || (st.stopped && st.stopped.has(tag))) return;
        const data = await this.files.readSealed(fileKey(c.id, id), m.file, k);
        await fsk.sendPiece(tag, k, data);
        if (!m.transfer || m.transfer.state !== 'done') this._progress(c.id, m, { state: 'uploading', done: Math.min((k + 1) * (SLOT - 16), m.file.size), total: m.file.size });
      }
    }).catch(e => this.log('serve: ' + e.message));
  }

  /* ---------- receiver side: the download loop ---------- */
  _dlSoon(contactId, msgId, ms) {
    const k = fileKey(contactId, msgId);
    const d = this.dl.get(k) || { contactId, msgId, tries: 0, running: false };
    d.next = Math.min(d.next || Infinity, Date.now() + ms);
    this.dl.set(k, d);
    if (ms <= 0) setImmediate(() => this._tick());
  }

  _dlKick(contactId) { for (const d of this.dl.values()) if (d.contactId === contactId && !d.running) { d.tries = 0; d.next = Date.now(); } }

  _dlTick(now) {
    const busy = new Set([...this.dl.values()].filter(d => d.running).map(d => d.contactId));
    for (const [k, d] of this.dl) {
      if (d.running || !d.next || d.next > now || busy.has(d.contactId)) continue;   // one download per contact at a time
      const c = this.store.contact(d.contactId);
      const m = c && this.store.chat(c.id).messages.find(x => x.id === d.msgId && x.dir === 'in' && x.kind === 'file');
      if (!m || m.transfer.state !== 'queued' || c.status === 'blocked') { this.dl.delete(k); continue; }
      busy.add(d.contactId);
      d.next = 0;
      this._download(c, m, d).catch(e => this.log('download: ' + e.message));
    }
  }

  async _download(c, m, d) {
    d.running = true; d.stop = false; d.cancel = null;
    const where = fileKey(c.id, m.id);
    const meta = m.file;
    let fh = null, failed = null, finished = false;
    try {
      const got0 = this.files.completePieces(where, meta);
      const need = (meta.size + meta.pieces * 16) - got0 * SLOT;
      if (this.files.freeSpace() < need + 200 * 1024 * 1024) throw Object.assign(new Error('Not enough free disk space for this file'), { stop: true });
      this._progress(c.id, m, { state: 'downloading', got: got0, done: Math.min(got0 * (SLOT - 16), meta.size), total: meta.size, err: null });
      const sock = await this._connection(c);
      fh = await this.files.openForDownload(where, got0);
      let got = got0, asked = got0;
      const gen = String(Date.now() % 1e9), tag = m.id + '/' + gen;   // this attempt's tag
      if (meta.pieces > 0) await new Promise((resolve, reject) => {
        let timer = null;
        const arm = () => { clearTimeout(timer); timer = setTimeout(() => done(Object.assign(new Error('The transfer stalled'), { code: 'UNREACHABLE' })), 90e3); };
        const ask = () => {
          while (asked - got < WINDOW && asked < meta.pieces) {
            const n = Math.min(8, meta.pieces - asked, WINDOW - (asked - got));
            sock.send({ t: 'get', id: m.id, g: gen, i: asked, n }); asked += n;
          }
        };
        let chain = Promise.resolve();
        const onFrame = f => {
          if (f.t === 'gone' && f.id === m.id) return done(Object.assign(new Error('The sender no longer has this file'), { stop: true }));
          if (f.t !== 'piece' || f.id !== tag) return;          // not for this attempt
          // pieces are checked and written strictly in order
          chain = chain.then(async () => {
            if (d.stop) return done(null, 'stopped');
            if (f.i < got) return;                         // a repeat (left over from before a pause): skip
            if (f.i !== got) throw new Error('pieces arrived out of order');
            openPiece(meta, m.id, f.i, f.data);              // throws if changed or damaged
            await fh.write(f.data, 0, f.data.length, f.i * SLOT);
            got++; arm();
            if (got % 16 === 0) { m.transfer.got = got; this.store.saveChat(c.id); }
            this._progress(c.id, m, { state: 'downloading', got, done: Math.min(got * (SLOT - 16), meta.size), total: meta.size });
            if (got >= meta.pieces) return done(null, 'ok');
            ask();
          }).catch(e => done(e));
        };
        const onClose = () => done(Object.assign(new Error('Connection closed'), { code: 'UNREACHABLE' }));
        let settled = false;
        const done = (err, v) => {
          if (settled) return; settled = true;
          clearTimeout(timer); sock.off('frame', onFrame); sock.off('close', onClose);
          if (got < meta.pieces && !sock.closed) { try { sock.send({ t: 'stop', id: m.id, g: gen }); } catch { /* closed */ } }
          if (err) reject(err); else resolve(v);
        };
        sock.on('frame', onFrame); sock.once('close', onClose);
        d.cancel = () => done(null, 'stopped');           // Pause / Decline stop at once
        if (d.stop) return done(null, 'stopped');
        arm(); ask();
      });
      finished = !d.stop && this.files.completePieces(where, meta) >= meta.pieces;
    } catch (e) {
      failed = e;
    } finally {
      if (fh) await fh.close().catch(() => {});
      d.running = false;
    }
    if (finished) {
      if (!this.files.isComplete(where, meta)) { failed = new Error('file size check failed'); finished = false; }
    }
    if (finished) {
      m.transfer = { state: 'done', got: meta.pieces, at: Date.now() };
      this.dl.delete(where);
      this._queueCtl(c.id, { k: 'filedone', fid: m.id, status: 'done' });
      this._soon(c.id, 300);
      this.store.saveChat(c.id); this.store.flush();
      this.emit('transfer', { contactId: c.id, id: m.id, transfer: m.transfer });
      this.emit('fileReady', { contactId: c.id, msg: m });
      return;
    }
    if (d.stop && !failed) { this.store.saveChat(c.id); return; }   // paused / declined by you
    const e = failed || new Error('Download interrupted');
    m.transfer.got = this.files.completePieces(where, meta);
    if (e.stop) { m.transfer = { ...m.transfer, state: 'failed', err: e.message }; this.dl.delete(where); }
    else {
      m.transfer = { ...m.transfer, state: 'queued', err: e.code === 'UNREACHABLE' ? 'Waiting for ' + (c.nick || c.name || 'contact') + ' to be online' : e.message };
      d.next = Date.now() + DL_RETRY[Math.min(d.tries++, DL_RETRY.length - 1)] * (0.85 + Math.random() * 0.3);
    }
    this.log(`download ${m.id.slice(0, 6)}: ${e.message}`);
    this.store.saveChat(c.id);
    this.emit('transfer', { contactId: c.id, id: m.id, transfer: m.transfer });
  }

  /** When a contact is due next (for "will retry in …"). */
  nextAttempt(id) { const s = this.sched.get(id); return s && s.next ? s.next : null; }
}

/* =================================================================
 * HELPERS (files)
 * ================================================================= */
function fmtSize(n) {
  if (n < 1024) return n + ' bytes';
  const u = ['KB', 'MB', 'GB', 'TB']; let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return (n >= 100 ? Math.round(n) : n.toFixed(1)) + ' ' + u[i];
}
function cleanMime(m) { m = String(m || '').toLowerCase().slice(0, 100); return /^[a-z0-9.+-]+\/[a-z0-9.+-]+$/.test(m) ? m : 'application/octet-stream'; }
/** A shared profile picture: a small JPEG/PNG as a data URL, or null. */
function cleanAvatar(a) { return typeof a === 'string' && a.length < 120000 && /^data:image\/(jpeg|png);base64,[A-Za-z0-9+/=]+$/.test(a) ? a : null; }
function cleanThumb(t) { return typeof t === 'string' && t.length < 90000 && /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(t) ? t : null; }

/** Checks a received file offer; returns the cleaned file info or null. */
function checkOffer(o) {
  const f = o && o.file;
  if (!f || typeof f !== 'object') return null;
  const size = Number(f.size), pieces = Number(f.pieces);
  if (!Number.isInteger(size) || size < 0 || size > MAX_FILE) return null;
  if (pieces !== piecesFor(size)) return null;
  let key, nonce;
  try { key = Buffer.from(String(f.key), 'base64'); nonce = Buffer.from(String(f.nonce), 'base64'); } catch { return null; }
  if (key.length !== 32 || nonce.length !== 8) return null;
  if (!/^[0-9a-f]{24}$/.test(String(o.id))) return null;
  return { name: safeName(f.name), size, pieces, mime: cleanMime(f.mime), key: key.toString('base64'), nonce: nonce.toString('base64'), thumb: cleanThumb(f.thumb) };
}

module.exports = { Peer, parseId, formatId, fmtSize, cleanAvatar };
