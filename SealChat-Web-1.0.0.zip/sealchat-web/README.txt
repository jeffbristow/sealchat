=====================================================================
 SEAL CHAT WEB 1.0.0 — the web interface for Seal Chat (PHP, no database)
=====================================================================

WHAT IT IS
  Use Seal Chat from your phone's browser (or any browser). You install
  these files on YOUR OWN web hosting. Seal Chat on your computer (1.4.0
  or newer) keeps your key and does all the real work; this web interface
  is a remote screen for it. Between the phone and your computer every
  message is sealed with a key only those two have — the website passes
  the sealed messages along and cannot read them.
  This is separate from the Seal Chat download / landing page website.

FILES
  index.php        the web interface (pairing, PIN, chats)
  app.js           what the screens do
  client.js        talking to your computer through relay.php
  crypto.js        the encryption (WebCrypto: P-256, HKDF, AES-256-GCM)
  relay.php        passes sealed messages between phone and computer
  admin.php        your setup page: on/off, connection link, computers,
                   admin password
  config.php       the only file to edit by hand (optional)
  lib.php          shared code (blocked from the browser)
  app.css, manifest.webmanifest, img/   look + "Add to Home Screen"
  assets/          setup page style + script
  vendor/jsQR.js   QR code reader for scanning the pairing code (Apache-2.0)
  wake/            small "wake" files Seal Chat watches (made automatically)
  .htaccess        blocks config/lib/.json files, forces HTTPS

INSTALL (shared hosting, PHP 8.x, HTTPS required)
  1. Upload this folder to your hosting, e.g. /public_html/chat/
     → https://yoursite.com/chat/
  2. Open https://yoursite.com/chat/admin.php
  3. Setup code: shown on that page as a file path — open
     <home>/sealchat-web-data/setup-code.txt in cPanel File Manager and
     copy the code. (Or put your own code in config.php first.)
  4. Choose your admin password (10+ characters).
  5. Tick "Turn the web interface on" → Save → "Copy link".
  6. Seal Chat on your computer: Settings → Web access → paste the link →
     Connect → Turn on → "Pair a device…".
  7. Phone: scan the QR code with the camera app, choose a PIN, check the
     6-digit code matches the one on your computer, click Approve there.
     iPhone: open the web interface in Safari, Share → "Add to Home Screen"
     FIRST and pair from that icon — it opens like an app, and Safari can't
     clear it after 7 days without use.

WHERE THE SETTINGS ARE KEPT
  A folder "sealchat-web-data" in your hosting HOME folder (e.g.
  /home/you/sealchat-web-data), outside public_html: admin.json (password
  hash), relay.json (on/off + relay code), setup-code.txt, sessions/ and
  relay/ (one mailbox per connected computer: who may use it + sealed
  messages waiting to be picked up — deleted when picked up, or after 3
  days). The exact path is shown on admin.php. If PHP can't write there,
  a "data" folder here is used instead (blocked by .htaccess).
  Forgot the admin password? Delete admin.json and open admin.php again.

TRAFFIC TO YOUR WEBSITE
  Off (in Seal Chat or here): nothing.
  On, nobody using the web interface: each connected computer asks for
  one tiny static file (wake/<random>.txt) every 30 s (Seal Chat setting:
  15 s – 5 min). The web server answers "304 Not Modified" without running
  PHP — about 1–2 KB per check; cPanel's bandwidth meter counts almost
  nothing for it.
  While the web interface is open: Seal Chat and the phone call relay.php,
  which holds one PHP process for up to 25 s per request; it goes back to
  the tiny checks 5 minutes after the page goes quiet.

SECURITY
  - The website never has your PGP key or readable messages.
  - Each phone/browser is paired by QR code + a code you compare, and
    protected by a PIN that your COMPUTER checks (10 wrong = removed).
  - Remove a device in Seal Chat → Settings → Web access; disconnect a
    computer here on admin.php.
  - "Make a new code" stops NEW computers using the old connection link.
  - admin.php: HTTPS only, bcrypt password, lockout after 5 wrong tries,
    sign-out after 30 idle minutes, CSRF protection.
  - The web interface's code comes from your hosting: keep your hosting
    account's password strong — whoever controls the files controls the
    page your phone runs.

TROUBLESHOOTING
  "Waking your computer…" for a long time: the computer must be on, awake
  and running Seal Chat with Web access on.
  Seal Chat shows a problem reaching the website "through Tor": some hosts
  block Tor — untick "Connect through Tor" in Seal Chat → Web access.
