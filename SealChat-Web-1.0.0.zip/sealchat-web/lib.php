<?php
/* =====================================================================
 * Seal Chat Web — lib.php   (shared code, 1.0.0)
 * ---------------------------------------------------------------------
 * Used by index.php (the web interface), relay.php (passes sealed
 * messages) and admin.php (your setup page). Blocked from the browser.
 *
 * Sections:
 *   1. Direct-access guard + config
 *   2. Where the settings live (outside public_html when possible)
 *   3. Reading / writing JSON safely (file lock + atomic replace)
 *   4. Relay settings (relay.json) + connected computers
 *   5. Output helpers (escaping, HTTPS check, security headers)
 * ===================================================================== */

/* =================================================================
 * 1. GUARD + CONFIG
 * ================================================================= */
if (!defined('SEALCHAT_WEB')) {
    http_response_code(404);
    exit;
}
const SEALCHAT_WEB_VERSION = '1.0.0';

function sc_config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $cfg = require __DIR__ . '/config.php';
        if (!empty($cfg['timezone'])) {
            @date_default_timezone_set($cfg['timezone']);
        }
    }
    return $cfg;
}

/* =================================================================
 * 2. DATA FOLDER
 * Default: "sealchat-web-data" in your HOME folder (e.g.
 * /home/you/sealchat-web-data) — never downloadable. Falls back to
 * ./data (blocked by .htaccess) when PHP can't write there.
 * ================================================================= */
function sc_data_dir(): string
{
    static $dir = null;
    if ($dir !== null) {
        return $dir;
    }
    $cfg = sc_config();
    $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
    $candidates = [];
    if (!empty($cfg['data_dir'])) {
        $candidates[] = rtrim($cfg['data_dir'], '/\\');
    }
    $home = sc_home_dir();
    if ($home !== '') {
        $candidates[] = $home . '/sealchat-web-data';
    }
    $candidates[] = __DIR__ . '/data';
    foreach ($candidates as $c) {
        $inWeb = $docRoot !== '' && str_starts_with($c . '/', rtrim($docRoot, '/') . '/');
        if ($inWeb && $c !== __DIR__ . '/data' && empty($cfg['data_dir'])) {
            continue;
        }
        if (!is_dir($c)) {
            @mkdir($c, 0700, true);
        }
        if (is_dir($c) && is_writable($c)) {
            if ($c === __DIR__ . '/data' && !file_exists($c . '/.htaccess')) {
                @file_put_contents($c . '/.htaccess', "Require all denied\nDeny from all\n");
            }
            return $dir = $c;
        }
    }
    http_response_code(500);
    exit('Seal Chat Web: no writable settings folder. Set data_dir in config.php.');
}

/** The account's home folder (/home/you), or '' if it can't be found. */
function sc_home_dir(): string
{
    $h = '';
    if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
        $pw = @posix_getpwuid(posix_geteuid());
        $h = is_array($pw) ? (string)($pw['dir'] ?? '') : '';
    }
    if ($h === '' || !@is_dir($h)) {
        $h = (string)(getenv('HOME') ?: ($_SERVER['HOME'] ?? ''));
    }
    if (($h === '' || !@is_dir($h)) && preg_match('~^(/home\d*/[^/]+)/~', __DIR__, $m)) {
        $h = $m[1];
    }
    return ($h !== '' && @is_dir($h)) ? rtrim($h, '/') : '';
}

/* =================================================================
 * 3. JSON FILES
 * ================================================================= */
function sc_read_json(string $name, array $default = []): array
{
    $file = sc_data_dir() . '/' . $name;
    if (!is_file($file)) {
        return $default;
    }
    $fh = @fopen($file, 'rb');
    if (!$fh) {
        return $default;
    }
    flock($fh, LOCK_SH);
    $raw = stream_get_contents($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    $data = json_decode((string)$raw, true);
    return is_array($data) ? $data : $default;
}

/** Writes to a temporary file, then swaps it in — a crash can't leave half a file. */
function sc_write_json(string $name, array $data): bool
{
    $file = sc_data_dir() . '/' . $name;
    $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false || @file_put_contents($tmp, $json, LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }
    @chmod($tmp, 0600);
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

/* =================================================================
 * 4. RELAY SETTINGS (relay.json) + CONNECTED COMPUTERS
 * relay.json: is the web interface on, and the relay code Seal Chat
 * needs to connect (part of the "connection link" on admin.php).
 * Mailboxes: <data folder>/relay/<mailbox id>/ — one per computer.
 * ================================================================= */
function sc_relay(): array
{
    $r = sc_read_json('relay.json', []);
    return [
        'enabled' => !empty($r['enabled']),
        'code'    => (string)($r['code'] ?? ''),
        'changed' => $r['changed'] ?? null,
    ];
}

function sc_relay_save(array $r): bool
{
    $r['changed'] = date('c');
    return sc_write_json('relay.json', $r);
}

/** A new random relay code like "K7QM-2XPA-9FDE-HT4W" (no look-alike letters). */
function sc_relay_new_code(): string
{
    $abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $out = '';
    for ($i = 0; $i < 16; $i++) {
        $out .= $abc[random_int(0, strlen($abc) - 1)];
        if ($i % 4 === 3 && $i < 15) {
            $out .= '-';
        }
    }
    return $out;
}

function sc_relay_dir(): string
{
    $d = sc_data_dir() . '/relay';
    if (!is_dir($d)) {
        @mkdir($d, 0700, true);
    }
    return $d;
}

/** The connected computers: [box => ['created', 'seen', 'devices']] for admin.php. */
function sc_relay_boxes(): array
{
    $out = [];
    foreach (glob(sc_relay_dir() . '/*/state.json') ?: [] as $f) {
        $st = json_decode((string)@file_get_contents($f), true);
        if (is_array($st)) {
            $out[basename(dirname($f))] = ['created' => $st['created'] ?? 0, 'seen' => $st['cSeen'] ?? 0, 'devices' => count($st['devices'] ?? [])];
        }
    }
    return $out;
}

/** Removes a computer's mailbox and its wake file. */
function sc_relay_remove_box(string $box): void
{
    if (!preg_match('/^[a-f0-9]{32}$/', $box)) {
        return;
    }
    $dir = sc_relay_dir() . '/' . $box;
    $st = json_decode((string)@file_get_contents($dir . '/state.json'), true);
    if (is_array($st) && preg_match('/^[a-f0-9]{32}$/', (string)($st['wake'] ?? ''))) {
        @unlink(__DIR__ . '/wake/' . $st['wake'] . '.txt');
    }
    foreach (glob($dir . '/*') ?: [] as $f) {
        @unlink($f);
    }
    @rmdir($dir);
}

/** This web interface's address (…/folder/), for the connection link. */
function sc_web_base(): string
{
    $host = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return (sc_is_https() ? 'https' : 'http') . '://' . $host . $dir . '/';
}

/* =================================================================
 * 5. OUTPUT HELPERS
 * ================================================================= */
function h(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function sc_is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') == 443);
}

function sc_is_localhost(): bool
{
    return in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
}

/** Security headers for admin.php. Everything (scripts, styles, images) is local. */
function sc_headers(): void
{
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('X-Frame-Options: DENY');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'");
    header('Cache-Control: no-store');
    header('X-Robots-Tag: noindex, nofollow');
}
