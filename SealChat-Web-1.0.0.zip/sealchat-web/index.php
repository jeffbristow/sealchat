<?php
/* =====================================================================
 * Seal Chat Web — index.php   (the web interface, 1.0.0)
 * ---------------------------------------------------------------------
 * The page you open on your phone (or any browser). It is only a remote
 * screen for Seal Chat running on YOUR computer: messages are read and
 * sent there, and travel between the two sealed (see crypto.js).
 * On an iPhone: Share → "Add to Home Screen" makes it open like an app.
 *
 * Files in this folder:
 *   index.php    this page (screens: start, pairing, PIN, chats)
 *   app.js       what the screens do
 *   client.js    talking to your computer through relay.php
 *   crypto.js    the encryption
 *   relay.php    passes sealed messages (can't read them)
 *   admin.php    your setup page (on/off, connection link, computers)
 *   lib.php, config.php   shared code + the one file to edit by hand
 *   app.css, manifest.webmanifest, img/, vendor/jsQR.js (QR scanning)
 *   wake/        the small "wake" files Seal Chat watches
 *
 * Sections:
 *   1. Settings + security headers
 *   2. Page head (phone / home-screen app settings)
 *   3. Screens: start · pair · unlock · chats
 * ===================================================================== */

define('SEALCHAT_WEB', true);
require __DIR__ . '/lib.php';

/* =================================================================
 * 1. SETTINGS + HEADERS
 * ================================================================= */
$cfg = sc_config();
$relay = sc_relay();
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');          // the pairing secret is in the address — never pass it on
header('X-Frame-Options: DENY');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; manifest-src 'self'; form-action 'none'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'");
header('Permissions-Policy: camera=(self), microphone=(), geolocation=()');
$https = sc_is_https() || sc_is_localhost();
$v = h(SEALCHAT_WEB_VERSION);

/* =================================================================
 * 2. HEAD
 * ================================================================= */
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#121418">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Seal Chat">
<meta name="format-detection" content="telephone=no">
<title>Seal Chat</title>
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" type="image/png" href="img/icon-192.png">
<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
<link rel="stylesheet" href="app.css?v=<?= $v ?>">
</head>
<body>

<?php /* =============================================================
       * 3. SCREENS
       * ============================================================= */ ?>

<?php if (!$https || !$relay['enabled']): ?>
<!-- web access is switched off on this website, or not over https -->
<section class="screen center">
  <div class="card">
    <img class="logo" src="img/icon-192.png" alt="">
    <h1>Seal Chat</h1>
    <?php if (!$https): ?>
      <p>Open this page with <b>https://</b> at the start of the address.</p>
    <?php else: ?>
      <p>The web interface is turned off.</p>
      <p class="muted small">Its owner can turn it on in <a href="admin.php">admin.php</a>.</p>
    <?php endif; ?>
  </div>
</section>
</body></html>
<?php exit; endif; ?>

<!-- 3a. start: this browser isn't paired yet -->
<section id="scrStart" class="screen center hidden">
  <div class="card">
    <img class="logo" src="img/icon-192.png" alt="">
    <h1>Seal Chat on this device</h1>
    <p class="muted">Read and send your Seal Chat messages here. Seal Chat keeps running on your computer and does the real work — your key never leaves it.</p>
    <ol class="steps">
      <li>On your computer: Seal Chat → <b>Settings → Web access</b>, turn it on, then <b>Pair a device…</b></li>
      <li>Scan the QR code it shows <span id="ssCamHint">with this device's camera</span>.</li>
    </ol>
    <button id="ssScan" class="btn primary wide">Scan the QR code</button>
    <details class="more"><summary>Or paste the pairing link</summary>
      <div class="row gap"><input id="ssLink" class="grow" placeholder="https://…/#pair=…" autocomplete="off" autocapitalize="off" spellcheck="false"><button id="ssGo" class="btn">Go</button></div>
    </details>
    <p id="ssHome" class="tip hidden">Tip: tap <b>Share</b> → <b>Add to Home Screen</b> first and pair from the new icon — it then opens like an app, and Safari can't clear it after a week without use.</p>
  </div>
</section>

<!-- 3b. pair: name + PIN, then compare the code -->
<section id="scrPair" class="screen center hidden">
  <div class="card">
    <img class="logo" src="img/icon-192.png" alt="">
    <h1>Pair this device</h1>
    <div id="prForm">
      <label>Name for this device<input id="prName" maxlength="40" autocomplete="off"></label>
      <label>Choose a PIN (4–12 digits)<input id="prPin" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="12" autocomplete="new-password"></label>
      <label>Repeat the PIN<input id="prPin2" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="12" autocomplete="new-password"></label>
      <p class="muted small">You type this PIN each time you open Seal Chat here. Your computer checks it — after 10 wrong PINs this device is removed.</p>
      <button id="prGo" class="btn primary wide">Pair</button>
    </div>
    <div id="prWait" class="hidden">
      <div class="spinner"></div>
      <p id="prStatus">Contacting your computer…</p>
      <div id="prCodeBox" class="hidden">
        <p class="muted small">Your computer shows a code. If it is the same as this one, click <b>Approve</b> there:</p>
        <div id="prCode" class="code"></div>
      </div>
    </div>
    <div class="error" id="prErr"></div>
    <button id="prCancel" class="link">Cancel</button>
  </div>
</section>

<!-- 3c. unlock: PIN, then wake the computer -->
<section id="scrLock" class="screen center hidden">
  <div class="card">
    <img class="logo" src="img/icon-192.png" alt="">
    <h1>Seal Chat</h1>
    <p class="muted small" id="lkName"></p>
    <form id="lkForm" autocomplete="off">
      <input id="lkPin" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="12" placeholder="PIN" autocomplete="current-password" aria-label="PIN">
      <button id="lkGo" class="btn primary wide">Unlock</button>
    </form>
    <div id="lkWait" class="hidden">
      <div class="spinner"></div>
      <p id="lkStatus">Connecting to your computer…</p>
      <p id="lkHint" class="muted small hidden">Seal Chat on your computer looks for the web interface every few seconds (Settings → Web access). It has to be on, awake and running Seal Chat with web access turned on.</p>
      <button id="lkStop" class="btn">Stop</button>
    </div>
    <div class="error" id="lkErr"></div>
    <button id="lkUnpair" class="link">Unpair this device…</button>
  </div>
</section>

<!-- 3d. chats -->
<section id="scrMain" class="screen hidden">
  <aside id="side">
    <header class="side-head">
      <img src="img/icon-192.png" alt="" class="brand-icon">
      <div class="grow">
        <b id="meName">Seal Chat</b>
        <div id="netState" class="net"><i class="dot"></i><span>Connected</span></div>
      </div>
      <button id="btnMenu" class="icon-btn" aria-label="Menu">⋯</button>
    </header>
    <input id="search" class="search" placeholder="Search" autocomplete="off" type="search">
    <div id="contactList" class="contact-list"></div>
  </aside>
  <main id="pane">
    <div id="emptyPane" class="empty-pane">
      <img src="img/icon-192.png" alt="" class="logo dim">
      <p class="muted">Choose a chat.</p>
    </div>
    <div id="chatPane" class="chat-pane hidden">
      <header class="chat-head">
        <button id="btnBack" class="icon-btn back" aria-label="Back">‹</button>
        <div id="chAvatar"></div>
        <div class="grow ch-title"><b id="chName"></b><div id="chSub" class="muted small"></div></div>
      </header>
      <div id="msgList" class="msg-list"></div>
      <form id="composer" class="composer" autocomplete="off">
        <textarea id="msgInput" rows="1" placeholder="Message" enterkeyhint="send"></textarea>
        <button id="btnSend" class="btn primary send" aria-label="Send">➤</button>
      </form>
    </div>
  </main>
</section>

<!-- pop-up menu, toast, QR scanner -->
<div id="menu" class="sheet hidden">
  <div class="sheet-box">
    <button data-act="refresh" class="sheet-item">Refresh</button>
    <button data-act="lock" class="sheet-item">Lock</button>
    <button data-act="unpair" class="sheet-item danger">Unpair this device…</button>
    <button data-act="close" class="sheet-item muted">Cancel</button>
  </div>
</div>
<div id="scanner" class="scanner hidden">
  <div class="scan-box">
    <h2>Scan the pairing QR code</h2>
    <div class="scan-view"><video id="scanVideo" playsinline muted></video><div class="scan-frame"></div></div>
    <p id="scanMsg" class="muted small">Point the camera at the QR code on your computer's screen.</p>
    <button id="scanClose" class="btn wide">Cancel</button>
  </div>
</div>
<div id="toast" class="toast hidden"></div>

<script src="crypto.js?v=<?= $v ?>"></script>
<script src="client.js?v=<?= $v ?>"></script>
<script src="app.js?v=<?= $v ?>"></script>
</body>
</html>
