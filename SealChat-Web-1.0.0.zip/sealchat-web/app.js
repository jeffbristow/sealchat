/* =====================================================================
   Seal Chat Web — app.js   (1.0.0)
   ---------------------------------------------------------------------
   The screens. Talking to your computer is in client.js; encryption in
   crypto.js. Nothing here is sent anywhere except sealed, to your own
   computer through relay.php.

   Sections:
     1. Helpers (escaping, times, toast, screens)
     2. This device's saved pairing (IndexedDB)
     3. Start + pairing (link or QR scan)
     4. Unlock with PIN (wakes your computer)
     5. Contacts
     6. A chat: history, bubbles, sending
     7. Live updates from your computer
     8. Menu, back button, background / auto-lock
     9. Start-up
   ===================================================================== */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var client = null;
  var me = { name: '' };
  var contacts = [];
  var currentId = null;
  var messages = [];
  var more = false;
  var pairInfo = null;
  var AUTO_LOCK_MS = 5 * 60000;      // locked again after 5 minutes in the background
  var PING_MS = 60000;               // keeps your computer listening while the page is open

  /* =================================================================
     1. HELPERS
     ================================================================= */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function linkify(text) {
    return esc(text).replace(/\bhttps?:\/\/[^\s<>"']+[^\s<>"'.,;:!?)\]]/g, function (u) { return '<a href="' + u + '" target="_blank" rel="noopener noreferrer">' + u + '</a>'; });
  }
  function timeOf(ts) { return new Date(ts).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); }
  function sameDay(a, b) { return new Date(a).toDateString() === new Date(b).toDateString(); }
  function dayLabel(ts) {
    var d = new Date(ts), now = new Date(), y = new Date(); y.setDate(now.getDate() - 1);
    if (sameDay(d, now)) return 'Today';
    if (sameDay(d, y)) return 'Yesterday';
    return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
  }
  function shortWhen(ts) {
    if (!ts) return '';
    var d = new Date(ts), now = new Date();
    if (sameDay(d, now)) return timeOf(ts);
    if (now - d < 6 * 86400000) return d.toLocaleDateString([], { weekday: 'short' });
    return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  }
  function fmtSize(n) { n = Number(n) || 0; if (n < 1024) return n + ' B'; if (n < 1048576) return (n / 1024).toFixed(0) + ' KB'; if (n < 1073741824) return (n / 1048576).toFixed(1) + ' MB'; return (n / 1073741824).toFixed(2) + ' GB'; }

  var toastTimer;
  function toast(text, bad) {
    var t = $('toast'); t.textContent = text; t.className = 'toast' + (bad ? ' bad' : '');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.add('hidden'); }, bad ? 5000 : 2600);
  }
  var SCREENS = ['scrStart', 'scrPair', 'scrLock', 'scrMain'];
  function show(id) { SCREENS.forEach(function (s) { $(s).classList.toggle('hidden', s !== id); }); }

  /** Initials on a colour from the contact's fingerprint, or their picture. */
  function avatarHtml(c, cls) {
    var initials = (c.name || '?').trim().split(/\s+/).map(function (w) { var m = /[\p{L}\p{N}]/u.exec(w); return m ? m[0] : ''; }).join('').slice(0, 2).toUpperCase() || '?';
    var color = 'c' + (parseInt(String(c.id || '0').slice(-4), 16) % 9 || 0);
    var pres = '<i class="pres' + (c.online ? ' on' : '') + '"></i>';
    if (c.avatar && /^data:image\/(jpeg|png);base64,/.test(c.avatar)) return '<div class="avatar ' + color + ' ' + (cls || '') + '"><img src="' + c.avatar + '" alt="">' + pres + '</div>';
    return '<div class="avatar ' + color + ' ' + (cls || '') + '">' + esc(initials) + pres + '</div>';
  }

  /** A short name for this device, e.g. "iPhone". */
  function deviceName() {
    var ua = navigator.userAgent;
    if (/iPhone/.test(ua)) return 'iPhone';
    if (/iPad/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)) return 'iPad';
    if (/Android/.test(ua)) return /Mobile/.test(ua) ? 'Android phone' : 'Android tablet';
    if (/Macintosh/.test(ua)) return 'Mac browser';
    if (/Windows/.test(ua)) return 'Windows browser';
    if (/Linux|X11/.test(ua)) return 'Linux browser';
    return 'Browser';
  }
  var isIos = /iPhone|iPad/.test(navigator.userAgent) || (/Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1);
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  var touch = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;

  /* =================================================================
     2. SAVED PAIRING (IndexedDB, this browser only)
     The device key is saved as a key object the page can use but never
     read out. (A browser that can't store key objects keeps the raw key.)
     ================================================================= */
  var storage = {
    db: function () {
      return new Promise(function (res, rej) {
        var r = indexedDB.open('sealchat-web', 1);
        r.onupgradeneeded = function () { r.result.createObjectStore('kv'); };
        r.onsuccess = function () { res(r.result); };
        r.onerror = function () { rej(r.error); };
      });
    },
    tx: function (mode, fn) {
      return storage.db().then(function (db) {
        return new Promise(function (res, rej) {
          var t = db.transaction('kv', mode), out;
          out = fn(t.objectStore('kv'));
          t.oncomplete = function () { res(out && out.result); db.close(); };
          t.onerror = t.onabort = function () { rej(t.error); db.close(); };
        });
      });
    },
    load: async function () {
      var rec = await storage.tx('readonly', function (s) { return s.get('device'); });
      if (rec && !rec.key && rec.keyRaw) rec.key = await SCCrypto.aesKey(new Uint8Array(rec.keyRaw));
      return rec || null;
    },
    save: async function (rec) {
      var copy = Object.assign({}, rec);
      delete copy.keyRaw;
      try { await storage.tx('readwrite', function (s) { return s.put(copy, 'device'); }); }
      catch (e) {
        // this browser can't store key objects → store the key bytes instead
        if (!rec.keyRaw) throw e;
        copy.key = null; copy.keyRaw = Array.from(rec.keyRaw);
        await storage.tx('readwrite', function (s) { return s.put(copy, 'device'); });
      }
      delete rec.keyRaw;
    },
    clear: function () { return storage.tx('readwrite', function (s) { return s.delete('device'); }); }
  };

  function newClient() {
    var c = new SCClient({ base: new URL('.', location.href).href, storage: storage });
    c.on('state', onNetState);
    c.on('push', onPush);
    c.on('revoked', onRevoked);
    return c;
  }

  /* =================================================================
     3. START + PAIRING
     ================================================================= */
  function showStart() {
    show('scrStart');
    $('ssHome').classList.toggle('hidden', !(isIos && !standalone));
    $('ssCamHint').textContent = standalone || !isIos ? 'with the button below' : "with your iPhone's Camera app, or the button below";
  }

  /** A pairing link arrived (address bar, paste or QR scan). */
  async function startPairing(hashOrLink) {
    var p = SCClient.parsePair(hashOrLink);
    if (!p) {
      if (/^sealchat:/i.test(String(hashOrLink).trim())) return toast('That is a Seal Chat ID (for adding contacts), not a pairing code. Use Settings → Web access → Pair a device… on your computer.', true);
      return toast('That is not a Seal Chat pairing link', true);
    }
    var existing = await storage.load().catch(function () { return null; });
    if (existing && !confirm('This device is already paired. Pair it again? (The old pairing stops working here.)')) return;
    pairInfo = p;
    show('scrPair');
    $('prForm').classList.remove('hidden'); $('prWait').classList.add('hidden'); $('prErr').textContent = '';
    $('prName').value = deviceName();
    $('prPin').value = $('prPin2').value = '';
    setTimeout(function () { $('prPin').focus(); }, 50);
  }

  $('prGo').onclick = async function () {
    $('prErr').textContent = '';
    var pin = $('prPin').value.trim(), name = $('prName').value.trim() || deviceName();
    if (!/^\d{4,12}$/.test(pin)) { $('prErr').textContent = 'The PIN must be 4 to 12 digits'; return; }
    if (pin !== $('prPin2').value.trim()) { $('prErr').textContent = 'The two PINs are different'; return; }
    $('prForm').classList.add('hidden'); $('prWait').classList.remove('hidden'); $('prCodeBox').classList.add('hidden');
    $('prStatus').textContent = 'Contacting your computer…';
    client = newClient();
    try {
      await client.pair(pairInfo, name, pin, function (code) {
        $('prCode').textContent = code;
        $('prCodeBox').classList.remove('hidden');
        $('prStatus').textContent = 'Waiting for you to approve on your computer…';
      });
      pairInfo = null;
      toast('Paired');
      unlockWith(pin);
    } catch (e) {
      $('prWait').classList.add('hidden'); $('prForm').classList.remove('hidden');
      $('prErr').textContent = e.message;
    }
  };
  $('prCancel').onclick = function () { pairInfo = null; boot(); };

  // start screen: paste / scan
  $('ssGo').onclick = function () { startPairing($('ssLink').value); };
  $('ssScan').onclick = function () { scanQr(); };

  /* ---------- QR scanner (camera, this page only) ---------- */
  var scan = null;
  function loadJsQr() {
    if (window.jsQR) return Promise.resolve();
    return new Promise(function (res, rej) { var s = document.createElement('script'); s.src = 'vendor/jsQR.js'; s.onload = res; s.onerror = function () { rej(new Error('Could not load the QR reader')); }; document.head.appendChild(s); });
  }
  async function scanQr() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return toast('This browser cannot use the camera here. Paste the pairing link instead.', true);
    try {
      await loadJsQr();
      var stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      var v = $('scanVideo');
      v.srcObject = stream; await v.play();
      $('scanner').classList.remove('hidden');
      var cv = document.createElement('canvas'), ctx = cv.getContext('2d', { willReadFrequently: true });
      scan = { stream: stream, timer: setInterval(function () {
        if (!v.videoWidth) return;
        var w = Math.min(800, v.videoWidth), h = Math.round(v.videoHeight * w / v.videoWidth);
        cv.width = w; cv.height = h; ctx.drawImage(v, 0, 0, w, h);
        var code = window.jsQR(ctx.getImageData(0, 0, w, h).data, w, h, { inversionAttempts: 'dontInvert' });
        if (code && code.data) { stopScan(); startPairing(code.data); }
      }, 250) };
    } catch (e) {
      stopScan();
      toast(e && e.name === 'NotAllowedError' ? 'Camera permission was refused. Allow it in Settings, or paste the pairing link.' : 'Camera: ' + (e.message || e), true);
    }
  }
  function stopScan() {
    if (scan) { clearInterval(scan.timer); scan.stream.getTracks().forEach(function (t) { t.stop(); }); scan = null; }
    $('scanner').classList.add('hidden');
  }
  $('scanClose').onclick = stopScan;

  /* =================================================================
     4. UNLOCK (PIN → wake your computer → welcome)
     ================================================================= */
  var hintTimer;
  function showLock(msg) {
    show('scrLock');
    $('lkForm').classList.remove('hidden'); $('lkWait').classList.add('hidden');
    $('lkErr').textContent = msg || '';
    $('lkName').textContent = client && client.rec ? 'Paired as "' + client.rec.name + '"' : '';
    $('lkPin').value = '';
    if (!touch) setTimeout(function () { $('lkPin').focus(); }, 50);
  }
  $('lkForm').onsubmit = function (e) {
    e.preventDefault();
    var pin = $('lkPin').value.trim();
    if (!/^\d{4,12}$/.test(pin)) { $('lkErr').textContent = 'Enter your PIN (4–12 digits)'; return; }
    unlockWith(pin);
  };
  async function unlockWith(pin) {
    show('scrLock');
    $('lkForm').classList.add('hidden'); $('lkWait').classList.remove('hidden'); $('lkErr').textContent = '';
    $('lkStatus').textContent = 'Connecting to your computer…';
    $('lkHint').classList.add('hidden');
    clearTimeout(hintTimer);
    hintTimer = setTimeout(function () { $('lkHint').classList.remove('hidden'); }, 25000);
    try {
      var w = await client.unlock(pin);
      clearTimeout(hintTimer);
      me = w.me || me;
      contacts = w.contacts || [];
      enterMain();
    } catch (e) {
      clearTimeout(hintTimer);
      if (e.message === 'Locked') return;
      client.stop();
      showLock(e.message);
    }
  }
  $('lkStop').onclick = function () { clearTimeout(hintTimer); client.lock(); client = rebuild(client); showLock(''); };
  $('lkUnpair').onclick = unpair;

  /** A fresh client with the same saved pairing. */
  function rebuild(old) { var c = newClient(); c.rec = old && old.rec; return c; }

  /* =================================================================
     5. CONTACTS
     ================================================================= */
  function enterMain() {
    show('scrMain');
    $('meName').textContent = me.name || 'Seal Chat';
    renderContacts();
    if (currentId) openChat(currentId, true);
    startPing();
  }

  function renderContacts() {
    var q = $('search').value.trim().toLowerCase();
    var list = contacts.filter(function (c) { return !q || (c.name || '').toLowerCase().indexOf(q) >= 0; });
    list.sort(function (a, b) { return (b.lastAt || 0) - (a.lastAt || 0); });
    if (!list.length) { $('contactList').innerHTML = '<p class="muted small pad">' + (q ? 'No match.' : 'No contacts yet. Add contacts in Seal Chat on your computer.') + '</p>'; return; }
    $('contactList').innerHTML = list.map(function (c) {
      var last = c.status === 'pending-in' ? 'Wants to chat — accept on your computer'
        : c.status === 'pending-out' ? 'Request sent' : c.status === 'blocked' ? 'Blocked' : (c.lastDir === 'out' ? 'You: ' : '') + (c.lastText || '');
      return '<button class="contact' + (c.id === currentId ? ' active' : '') + (c.status === 'pending-in' ? ' request' : '') + '" data-id="' + esc(c.id) + '">'
        + avatarHtml(c) + '<span class="meta"><span class="top"><span class="nm">' + esc(c.name) + '</span><span class="when">' + esc(shortWhen(c.lastAt)) + '</span></span>'
        + '<span class="bottom"><span class="last">' + esc(last) + '</span>' + (c.unread ? '<span class="unread">' + c.unread + '</span>' : '') + '</span></span></button>';
    }).join('');
  }
  $('contactList').onclick = function (e) { var b = e.target.closest('.contact'); if (b) openChat(b.dataset.id); };
  $('search').oninput = renderContacts;

  /* =================================================================
     6. A CHAT
     ================================================================= */
  var narrow = function () { return window.matchMedia('(max-width: 760px)').matches; };

  async function openChat(id, keep) {
    var c = contacts.find(function (x) { return x.id === id; });
    if (!c) return;
    if (!keep && narrow() && currentId !== id) history.pushState({ chat: id }, '');
    currentId = id;
    $('scrMain').classList.add('in-chat');
    $('emptyPane').classList.add('hidden'); $('chatPane').classList.remove('hidden');
    renderHead(c);
    renderContacts();
    var canSend = c.status === 'accepted' || c.status === 'pending-out';
    $('msgInput').disabled = $('btnSend').disabled = !canSend;
    $('msgInput').placeholder = canSend ? 'Message' : c.status === 'pending-in' ? 'Accept their request on your computer first' : 'You can\'t message this contact';
    if (!keep) { messages = []; $('msgList').innerHTML = '<p class="muted small center pad">Loading…</p>'; }
    try {
      var h = await client.ask('history', { cid: id });
      if (currentId !== id) return;
      messages = h.msgs || []; more = !!h.more;
      renderMessages(true);
      markRead();
    } catch (e) { toast(e.message, true); }
  }

  function renderHead(c) {
    $('chAvatar').innerHTML = avatarHtml(c, 'sm');
    $('chName').textContent = c.name;
    $('chSub').textContent = c.status === 'pending-out' ? 'Request sent — waiting for them to accept' : c.online ? 'Online' : c.lastSeen ? 'Last seen ' + shortWhen(c.lastSeen) : '';
  }

  function closeChat() {
    currentId = null;
    $('scrMain').classList.remove('in-chat');
    $('chatPane').classList.add('hidden'); $('emptyPane').classList.remove('hidden');
    renderContacts();
  }
  $('btnBack').onclick = function () { if (history.state && history.state.chat) history.back(); else closeChat(); };
  window.addEventListener('popstate', function () { if (currentId && narrow()) closeChat(); });

  function markRead() {
    if (!currentId || document.hidden) return;
    var c = contacts.find(function (x) { return x.id === currentId; });
    if (c && c.unread) { c.unread = 0; renderContacts(); }
    client.ask('read', { cid: currentId }).catch(function () {});
  }

  function tick(m) {
    if (m.dir !== 'out') return '';
    if (m.state === 'sending') return '<span class="tick">…</span>';
    if (m.state === 'failed') return '<span class="tick bad">!</span>';
    if (m.state === 'queued') return '<span class="tick" title="Waiting to send — goes when they are online">⏱</span>';
    if (m.state === 'read') return '<span class="tick read">✓✓</span>';
    return '<span class="tick">✓</span>';
  }

  function bubble(m, same) {
    var body;
    if (m.kind === 'file' && m.file) {
      body = '<div class="file"><span class="ficon">📎</span><span><b>' + esc(m.file.name) + '</b><br><span class="muted small">' + fmtSize(m.file.size) + ' · open it in Seal Chat on your computer</span></span></div>' + (m.text ? '<div class="txt">' + linkify(m.text) + '</div>' : '');
    } else body = '<div class="txt">' + linkify(m.text) + '</div>';
    return '<div class="bubble ' + m.dir + (m.state === 'queued' || m.state === 'sending' ? ' queued' : '') + (m.state === 'failed' ? ' failed' : '') + (same ? ' same' : '') + '" data-id="' + esc(m.id) + '">' + body
      + '<div class="ft">' + (m.state === 'failed' ? '<span class="bad">Not sent · tap to retry</span>' : '') + '<span>' + timeOf(m.at) + '</span>' + tick(m) + '</div></div>';
  }

  function renderMessages(toEnd) {
    var list = $('msgList');
    var nearBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 120;
    var html = more ? '<button id="loadMore" class="btn small center-btn">Show earlier messages</button>' : '';
    if (!messages.length) html += '<p class="muted small center pad">No messages yet.</p>';
    var prev = null;
    messages.forEach(function (m) {
      if (!prev || !sameDay(prev.at, m.at)) html += '<div class="day">' + esc(dayLabel(m.at)) + '</div>';
      var same = prev && prev.dir === m.dir && m.at - prev.at < 120000 && sameDay(prev.at, m.at);
      html += bubble(m, same);
      prev = m;
    });
    list.innerHTML = html;
    if (toEnd || nearBottom) list.scrollTop = list.scrollHeight;
    var lm = $('loadMore');
    if (lm) lm.onclick = loadEarlier;
  }

  async function loadEarlier() {
    if (!messages.length) return;
    var id = currentId, list = $('msgList'), h0 = list.scrollHeight;
    try {
      var h = await client.ask('history', { cid: id, before: messages[0].id });
      if (currentId !== id) return;
      messages = (h.msgs || []).concat(messages); more = !!h.more;
      renderMessages(false);
      list.scrollTop = list.scrollHeight - h0;
    } catch (e) { toast(e.message, true); }
  }

  // tap a failed bubble to send it again
  $('msgList').onclick = function (e) {
    var b = e.target.closest('.bubble.failed');
    if (!b) return;
    var m = messages.find(function (x) { return x.id === b.dataset.id; });
    if (m) { messages.splice(messages.indexOf(m), 1); sendText(m.text); }
  };

  var tmpN = 0;
  async function sendText(text) {
    var cid = currentId;
    var tmp = { id: 'tmp' + (++tmpN), dir: 'out', text: text, at: Date.now(), state: 'sending' };
    messages.push(tmp); renderMessages(true);
    try {
      var r = await client.ask('send', { cid: cid, text: text, tmp: tmp.id });
      var i = messages.indexOf(tmp);
      if (messages.some(function (x) { return x.id === r.msg.id; })) { if (i >= 0) messages.splice(i, 1); }   // already arrived as a live update
      else if (i >= 0) messages[i] = r.msg;
      var c = contacts.find(function (x) { return x.id === cid; });
      if (c) { c.lastAt = r.msg.at; c.lastText = text; c.lastDir = 'out'; }
    } catch (e) {
      tmp.state = 'failed';
      toast(e.message, true);
    }
    if (currentId === cid) renderMessages(false);
    renderContacts();
  }

  $('composer').onsubmit = function (e) {
    e.preventDefault();
    var t = $('msgInput').value;
    if (!t.trim() || !currentId) return;
    $('msgInput').value = ''; autoSize();
    sendText(t);
    if (!touch) $('msgInput').focus();
  };
  function autoSize() { var t = $('msgInput'); t.style.height = 'auto'; t.style.height = Math.min(140, t.scrollHeight + 2) + 'px'; }
  $('msgInput').oninput = autoSize;
  $('msgInput').onkeydown = function (e) {
    // computer keyboard: Enter sends, Shift+Enter = new line. Phones: the Send button.
    if (e.key === 'Enter' && !e.shiftKey && !touch && !e.isComposing) { e.preventDefault(); $('composer').requestSubmit(); }
  };

  /* =================================================================
     7. LIVE UPDATES
     ================================================================= */
  function onPush(o) {
    if (o.t === 'contacts' && Array.isArray(o.list)) {
      contacts = o.list;
      if (currentId && document.visibilityState === 'visible') { var c = contacts.find(function (x) { return x.id === currentId; }); if (c) { renderHead(c); if (c.unread) markRead(); } }
      renderContacts();
    } else if (o.t === 'msg' && o.msg) {
      if (o.cid === currentId) {
        var at = messages.findIndex(function (x) { return x.id === o.msg.id; });
        if (at >= 0) messages[at] = o.msg;
        else if (!messages.some(function (x) { return x.state === 'sending' && x.text === o.msg.text && o.msg.dir === 'out'; })) messages.push(o.msg);
        renderMessages(false);
        if (o.msg.dir === 'in') markRead();
      }
    } else if (o.t === 'states' && o.cid === currentId) {
      var map = {};
      (o.states || []).forEach(function (s) { map[s[0]] = s[1]; });
      messages.forEach(function (m) { if (map[m.id]) m.state = map[m.id]; });
      renderMessages(false);
    }
  }

  function onNetState(s) {
    var el = $('netState');
    var text = { online: 'Connected to your computer', waking: 'Waking your computer…', 'computer-quiet': 'Your computer is not answering', 'no-website': 'No connection to the website', 'relay-off': 'The web interface is turned off (admin.php)' }[s] || s;
    el.className = 'net ' + (s === 'online' ? 'on' : s === 'waking' ? 'wait' : 'bad');
    el.querySelector('span').textContent = text;
    if (!$('scrLock').classList.contains('hidden') && !$('lkWait').classList.contains('hidden')) {
      $('lkStatus').textContent = s === 'waking' ? 'Waking your computer… (it checks every few seconds)' : s === 'no-website' ? 'No connection to the website — retrying…' : s === 'relay-off' ? 'The web interface is turned off (admin.php)' : 'Connecting to your computer…';
    }
  }

  async function onRevoked(why) {
    try { await storage.clear(); } catch (e) { /* ignore */ }
    if (client) client.stop();
    client = null; contacts = []; currentId = null;
    showStart();
    toast(why === 'pin' ? 'Too many wrong PINs — this device was removed. Pair it again from your computer.' : why === 'nobox' ? 'Your computer disconnected from this website. Pair again after turning web access back on.' : 'This device was removed in Seal Chat on your computer.', true);
  }

  /* =================================================================
     8. MENU, BACKGROUND, AUTO-LOCK
     ================================================================= */
  $('btnMenu').onclick = function () { $('menu').classList.remove('hidden'); };
  $('menu').onclick = function (e) {
    var b = e.target.closest('[data-act]');
    if (!b && e.target !== $('menu')) return;
    $('menu').classList.add('hidden');
    var act = b && b.dataset.act;
    if (act === 'refresh') refresh();
    if (act === 'lock') lockNow();
    if (act === 'unpair') unpair();
  };

  async function refresh() {
    try {
      var r = await client.ask('contacts', {});
      contacts = r.list || []; renderContacts();
      if (currentId) openChat(currentId, true);
    } catch (e) { toast(e.message, true); }
  }

  function lockNow() {
    stopPing();
    if (client) { client.lock(); client = rebuild(client); }
    contacts = []; messages = [];
    showLock('');
  }

  async function unpair() {
    if (!confirm('Unpair this device? You will need to pair it again from your computer to use Seal Chat here.')) return;
    try { if (client && client.sid) await client.tell('unpair', { sid: client.sid }); } catch (e) { /* computer offline: remove it there later */ }
    stopPing();
    if (client) client.stop();
    await storage.clear().catch(function () {});
    client = null; currentId = null;
    showStart();
    toast('This device is unpaired');
  }

  var pingTimer = null;
  function startPing() { stopPing(); pingTimer = setInterval(function () { if (client && client.sid && !document.hidden) client.ask('ping', {}, 90000).catch(function () {}); }, PING_MS); }
  function stopPing() { clearInterval(pingTimer); pingTimer = null; }

  // background: stop listening; after 5 minutes away, ask for the PIN again
  var hiddenAt = 0;
  document.addEventListener('visibilitychange', function () {
    if (!client || !client.rec) return;
    if (document.hidden) { hiddenAt = Date.now(); if (client.sid) client.stop(); return; }
    if (!client.sid) return;
    if (Date.now() - hiddenAt > AUTO_LOCK_MS) { lockNow(); return; }
    client.start();
    client.wake();
    refresh();
  });

  /* =================================================================
     9. START-UP
     ================================================================= */
  async function boot() {
    var hash = location.hash;
    if (/pair=/.test(hash)) {
      history.replaceState(null, '', location.pathname + location.search);   // the secret leaves the address bar
      return startPairing(hash);
    }
    var rec = null;
    try { rec = await storage.load(); } catch (e) { toast('This browser blocks saving (private mode?) — pairing won\'t be kept.', true); }
    if (!rec) return showStart();
    client = newClient(); client.rec = rec;
    showLock('');
  }
  // a pairing link opened in a tab that already shows this page
  window.addEventListener('hashchange', function () { if (/pair=/.test(location.hash)) boot(); });
  if (!window.crypto || !window.crypto.subtle) { document.body.innerHTML = '<p class="pad">This page needs https:// and a current browser.</p>'; return; }
  boot();
})();
